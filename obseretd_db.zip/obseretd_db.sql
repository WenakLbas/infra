-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Dec 12, 2022 at 07:46 AM
-- Server version: 5.7.23-23
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `obseretd_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `activites`
--

CREATE TABLE `activites` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(400) NOT NULL,
  `date` varchar(150) NOT NULL,
  `heure` varchar(400) NOT NULL,
  `lieu` varchar(600) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `actualites`
--

CREATE TABLE `actualites` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(400) NOT NULL,
  `slag` text NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `actualites`
--

INSERT INTO `actualites` (`id`, `titre`, `slag`, `description`, `imgurl`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(44, 'Lancement de Projet de mise en place de l’Observatoire de la Violence', 'Le consortium ENA-CERGIED-CRASH a lancé ce mercredi 02 mars 2022, le projet d’appui à la mise en place et au développement de l’Observatoire de la Violence de la Prévention de la Criminalité et de la Déontologie Policière (OVPCDP). C’était dans les locaux de l’École Nationale d’Administration. La cérémonie a été présidée par le Ministre de la Sécurité Publique et de l’Immigration, Président du Comité de Pilotage du Projet, le Général Idriss Dokony Adiker, en présence de quelques Ministres et des Partenaires Techniques et Financiers.', '<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><em><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le consortium ENA-CERGIED-CRASH a lanc&eacute; ce mercredi 02 mars 2022, le projet d&rsquo;appui &agrave; la mise en place et au d&eacute;veloppement de l&rsquo;Observatoire de la Violence de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re (OVPCDP). C&rsquo;&eacute;tait dans les locaux de l&rsquo;&Eacute;cole Nationale d&rsquo;Administration. La c&eacute;r&eacute;monie a &eacute;t&eacute; pr&eacute;sid&eacute;e par le Ministre de la S&eacute;curit&eacute; Publique et de l&rsquo;Immigration, Pr&eacute;sident du Comit&eacute; de Pilotage du Projet, le G&eacute;n&eacute;ral Idriss Dokony Adiker, en pr&eacute;sence de quelques Ministres et des Partenaires Techniques et Financiers. </span></em></strong></span></span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le projet d&rsquo;appui &agrave; la mise en place de l&rsquo;Observatoire est financ&eacute; par l&rsquo;Union Europ&eacute;enne &agrave; travers le PAASIT (Projet d&rsquo;Appui &agrave; l&rsquo;Am&eacute;lioration de la S&eacute;curit&eacute; Int&eacute;rieure au Tchad) et sera mis en &oelig;uvre par le consortium constitu&eacute; de </span><span style=\"font-family:&quot;Times New Roman&quot;,serif\">l&rsquo;&Eacute;cole Nationale d&rsquo;Administration (ENA), du </span><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Centre d&rsquo;&Eacute;tudes et de Recherches sur la Gouvernance, les Industries Extractives et le D&eacute;veloppement Durable&nbsp;(</span><span style=\"font-family:&quot;Times New Roman&quot;,serif\">CERGIED) et du Centre de Recherches en Anthropologie et Sciences Humaines&nbsp;(CRASH)</span><span style=\"font-family:&quot;Times New Roman&quot;,serif\">. </span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">D&rsquo;un montant de pr&egrave;s d&rsquo;un million d&rsquo;Euro, le projet a pour objectif de rendre fonctionnel l&rsquo;Observatoire de la Violence de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re (OVPCDP). Parmi les objectifs sp&eacute;cifiques, il s&rsquo;agit d</span><span style=\"font-family:&quot;Times New Roman&quot;,serif\">&rsquo;appuyer la production et la diffusion de l&rsquo;information &agrave; travers la r&eacute;alisation des &eacute;tudes scientifiques ind&eacute;pendantes au profit de l&rsquo;Etat, des institutions publiques et des partenaires priv&eacute;s sur les questions li&eacute;es &agrave; la violence, &agrave; la pr&eacute;vention de la criminalit&eacute; et &agrave; la d&eacute;ontologie polici&egrave;re mais aussi de renforcer la gouvernance s&eacute;curitaire gr&acirc;ce &agrave; l&rsquo;offre des services et l&rsquo;am&eacute;lioration de la qualit&eacute; des relations Forces de S&eacute;curit&eacute; Int&eacute;rieure et la citoyens. </span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Dans son mot de bienvenue, le Coordonnateur du projet de mise en place de l&rsquo;observatoire Senoussi Hassana Abdoulaye a remerci&eacute; la D&eacute;l&eacute;gation de l&rsquo;Union Europ&eacute;enne &agrave; travers le service FED pour avoir choisi le consortium ENA-CERGIED-CRASH pour la mise en place dudit projet. Il a ensuite pr&eacute;sent&eacute; les diff&eacute;rents membres du consortium qui, selon lui, repr&eacute;sente la preuve de la collaboration entre les institutions publiques et priv&eacute;es en mati&egrave;re de recherche appliqu&eacute;e. </span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le coordonnateur du Projet d&rsquo;Appui &agrave; l&rsquo;Am&eacute;lioration de la S&eacute;curit&eacute; Int&eacute;rieure au Tchad (PAASIT), le G&eacute;n&eacute;ral Abdoulaye Georges Moyalta s&rsquo;est appesanti sur le r&ocirc;le que devra jouer l&rsquo;Observatoire dans le renforcement de l&rsquo;efficience des diff&eacute;rentes Forces de S&eacute;curit&eacute;. Il a &eacute;galement cit&eacute; quelques principes qui devront veiller au bon fonctionnement de l&rsquo;Observatoire. Il s&rsquo;agit de l&rsquo;ind&eacute;pendance, l&rsquo;autonomie, la qualit&eacute; scientifique des m&eacute;thodes de collecte et d&rsquo;analyse des donn&eacute;es, la pluridisciplinarit&eacute; et le respect des r&egrave;gles de s&eacute;curit&eacute;. </span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"background-color:white\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:#222222\">L&rsquo;Ambassadeur chef de D&eacute;l&eacute;gation de l&rsquo;Union Europ&eacute;enne a d&eacute;clar&eacute; que le Tchad est soutenu par la DUE sur plusieurs projets de S&eacute;curit&eacute; Int&eacute;rieure &agrave; hauteur de 13 milliards FCFA.&nbsp; Kurt Cornelis, a relev&eacute; ensuite que la s&eacute;curit&eacute; constitue avant tout un service public&nbsp;&laquo;&nbsp;</span></span></span><em><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:#222222\">La s&eacute;curit&eacute; &eacute;tant une affaire d&rsquo;hommes et de femmes devant faire preuve d&rsquo;une culture d&rsquo;efficacit&eacute; et de respect des droits humains. En outre, l&rsquo;am&eacute;lioration de la s&eacute;curit&eacute; a &eacute;galement pour objectif de contribuer &agrave; replacer le pays dans les meilleures conditions pour retrouver le chemin de la croissance &eacute;conomique&nbsp;</span></span></em><span style=\"background-color:white\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:#222222\">&raquo;. </span></span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:Times\">Dans son discours de lancement le Ministre de la S&eacute;curit&eacute; Publique et de l&rsquo;Immigration, </span><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Pr&eacute;sident du Comit&eacute; de Pilotage du Projet,<strong><em> </em></strong></span><span style=\"font-family:Times\">le G&eacute;n&eacute;ral Idriss Dokony Adiker a rappel&eacute; l&rsquo;engagement du gouvernement &agrave; vouloir am&eacute;liorer le secteur de la S&eacute;curit&eacute; int&eacute;rieure. Il a soulign&eacute; que &laquo;&nbsp;<em>l</em></span><em><span style=\"background-color:white\"><span style=\"font-family:Times\"><span style=\"color:#222222\">es forces de d&eacute;fense et de s&eacute;curit&eacute; ne sont pas tr&egrave;s souvent respect&eacute;es, laissant la place &agrave; toutes formes de d&eacute;rives s&eacute;curitaires</span></span></span></em><span style=\"background-color:white\"><span style=\"font-family:Times\"><span style=\"color:#222222\">&nbsp;&raquo;. Ce projet permettra d&rsquo;apr&egrave;s lui de mieux ajuster les r&eacute;ponses des Forces de D&eacute;fense et de S&eacute;curit&eacute;.</span></span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><em><u><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Premi&eacute;re r&eacute;union du Comit&eacute; de Pilotage&nbsp;</span></span></u></em></strong><strong><em><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">:</span></span></em></strong></span></span></p>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">La premi&egrave;re rencontre du Comit&eacute; de Pilotage de l&rsquo;Observatoire s&rsquo;est tenue le 02 Mars 2022, dans la salle BINTOU MALLOUM de l&rsquo;Ecole Nationale d&rsquo;Administration. </span></span><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Ouvrant la s&eacute;ance, le Ministre de la S&eacute;curit&eacute; Publique et de l&rsquo;Immigration a adress&eacute; les remerciements &agrave; ses vis-&agrave;-vis pour avoir r&eacute;pondu &agrave; l&rsquo;invitation pour la premi&egrave;re r&eacute;union du Comit&eacute; de Pilotage de l&rsquo;Observatoire. </span></span></span></span></p>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Apr&egrave;s la phase des pr&eacute;sentations des membres, l&rsquo;orateur a resitu&eacute; le contexte de la rencontre. A cet effet, le Ministre a rappel&eacute; que depuis quelques ann&eacute;es d&eacute;j&agrave;, le Minist&egrave;re de la S&eacute;curit&eacute; Publique et de l&rsquo;Immigration s&rsquo;est lanc&eacute; dans une politique de modernisation des FSI. Et, l&rsquo;Observatoire a une place de choix dans le processus de professionnalisation des Forces de S&eacute;curit&eacute; Int&eacute;rieures et de renouv&egrave;lement de leurs outils de travail. Rappelant que selon le D&eacute;cret N&deg; 1944/PR/MSPI/2020, en son Article 6&nbsp;: <em>le Comit&eacute; de Pilotage est l&#39;organe d&#39;orientation strat&eacute;gique et de d&eacute;cision de I&#39;OVPCDP, l&rsquo;orateur<a name=\"_Hlk97031736\"> </a></em>a propos&eacute; de proc&eacute;der &agrave; l&rsquo;adoption de l&rsquo;Ordre du Jour&nbsp;qui &eacute;tait pr&eacute;alablement pr&eacute;vu en 3 points, en plus des divers :</span></span></span></span></p>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\">&nbsp;</p>\r\n\r\n<ul>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><a name=\"_Hlk96765106\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Etat d&rsquo;avancement et perspectives du projet ;</span></span></a></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">D&eacute;finition des crit&egrave;res de d&eacute;signation des membres du Comit&eacute; Scientifique de l&rsquo;Observatoire ;</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Implication du Minist&egrave;re de la S&eacute;curit&eacute; Publique et de l&rsquo;Immigration dans la collecte des donn&eacute;es&nbsp;;</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Divers.</span></span></span></span></li>\r\n</ul>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">C&rsquo;est pendant la premi&egrave;re rencontre du COPIL que la question de la d&eacute;signation des membres du Comit&eacute; Scientifique a &eacute;t&eacute; d&eacute;battue. En effet, selon le D&eacute;cret <span style=\"color:black\">N&deg; 1944/PR/MSPI/2020</span>, les crit&egrave;res de s&eacute;lection des membres de cet organes devaient &ecirc;tre valid&eacute;s pendant la rencontre du COPIL.</span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">A ce titre, l&rsquo;&eacute;quipe du projet a fait des propositions de crit&egrave;res &agrave; l&rsquo;assistance.</span></span></span></p>\r\n\r\n<ul style=\"list-style-type:circle\">\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Crit&egrave;res &agrave; caract&egrave;re institutionnel&nbsp;: &ecirc;tre issu d&rsquo;institutions publiques, parapubliques et priv&eacute;es de recherche&nbsp;;</span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Crit&egrave;res &agrave; caract&egrave;re acad&eacute;mique : &ecirc;tre titulaire d&rsquo;un doctorat&nbsp;;</span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Domaine d&rsquo;expertise : production scientifique, notamment dans les domaines de pr&eacute;dilection de l&rsquo;Observatoire&nbsp;; </span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Exp&eacute;rience&nbsp;: pouvoir justifier d&#39;une activit&eacute; de recherche prolifique et innovante, avoir une exp&eacute;rience dans un organe semblable au Comit&eacute; Scientifique.</span></span></span></li>\r\n</ul>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">L&rsquo;assistance s&rsquo;&eacute;tant prononc&eacute;e en faveur de la proposition du Consortium ENA-CERGIED-CRASH, le MSPI a pu prendre, en date du 05 avril 2022, la D&eacute;cision N&deg;001/PCMT/PMT/MSPI/SG/DCP/OVPCDP/2022 portant d&eacute;finition des crit&egrave;res de s&eacute;lection des membres du SC de l&rsquo;OVPCDP.</span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Dans cette D&eacute;cision, mandat a &eacute;t&eacute; donn&eacute; audit Consortium de proc&eacute;der &agrave; la mise en &oelig;uvre de la proc&eacute;dure de s&eacute;lections des membres du Comit&eacute; Scientifique.</span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"><span style=\"color:black\">Dans son mot, le Ministre a exprim&eacute; sa satisfaction par rapport &agrave; l&rsquo;&eacute;tat d&rsquo;avancement du projet, et &agrave; encourager les &eacute;quipes &agrave; avancer sur le m&ecirc;me &eacute;lan.<em> </em>Il a d&eacute;clar&eacute; que les crit&egrave;res &eacute;tant connus, les membres du Consortium doivent d&eacute;clencher la proc&eacute;dure de s&eacute;lection objective des membres r&eacute;pondants audits crit&egrave;res. Pour finir, le Ministre de la S&eacute;curit&eacute;<em> </em>a rassur&eacute; le Consortium et les Partenaires Techniques et Financiers associ&eacute;s au projet de toute la disponibilit&eacute; et de la pleine implication du Minist&egrave;re dans la collecte des donn&eacute;es. Il a par la m&ecirc;me occasion, invit&eacute; les autres membres du Comit&eacute; de Pilotage &agrave; s&rsquo;investir pour appuyer les &eacute;quipes en charge de la gestion du projet &agrave; r&eacute;ussir leur mission dans la mise en &oelig;uvre de l&rsquo;Observatoire.</span></span></span></span></p>', 'https://observatoire-td.org/observer/public/images/actualites/ministre-64313718_1663674618.png', '2022-10-12 12:19:07', '2022-10-12 12:19:07', 42, NULL),
(45, 'Formation de 49 assistants chercheurs', '49 assistants chercheurs ont reçu une formation à l’ENA, le samedi 21 mai 2022 sur la méthodologie des collectes des données et la présentation des outils de collecte des données. Cette formation entre dans le cadre du projet de mise en place et de développement de l’Observatoire qui a prévu de créer un réseau de partenariat institutionnel pour la collecte des informations sur les questions de violence, de délinquance, de criminalité et de déontologie policière. La formation a été lancée par le Coordonnateur du projet, Senoussi Hassana Abdoulaye.', '<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><em><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">49 assistants chercheurs ont re&ccedil;u une formation &agrave; l&rsquo;ENA, le samedi 21 mai 2022 sur la m&eacute;thodologie des collectes des donn&eacute;es et la pr&eacute;sentation des outils de collecte des donn&eacute;es. Cette formation entre dans le cadre du projet de mise en place et de d&eacute;veloppement de l&rsquo;Observatoire qui a pr&eacute;vu de cr&eacute;er un r&eacute;seau de partenariat institutionnel pour la collecte des informations sur les questions de violence, de d&eacute;linquance, de criminalit&eacute; et de d&eacute;ontologie polici&egrave;re. La formation a &eacute;t&eacute; lanc&eacute;e par le Coordonnateur du projet, Senoussi Hassana Abdoulaye. </span></span></em></strong></span></span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le projet de mise en place de l&rsquo;Observatoire a initi&eacute; la formation de 49 assistants chercheurs afin de collecter et de remonter des informations sp&eacute;cifiques &agrave; travers des rapports mensuels sur la violence, la d&eacute;linquance, la criminalit&eacute; et les infractions commises par les FSI. </span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Initialement, 23 personnes (repr&eacute;sentant toutes les provinces du Tchad) &eacute;taient pr&eacute;vues pour cette activit&eacute; explique le coordonnateur du projet Senoussi Hassana Abdoulaye&nbsp;Cependant<em>,&nbsp;&laquo;&nbsp;le projet a jug&eacute; n&eacute;cessaire de doubler le nombre afin d&rsquo;obtenir plus de donn&eacute;es. C&rsquo;est ainsi que des correspondances ont &eacute;t&eacute; envoy&eacute;es &agrave; plusieurs institutions et associations, notamment le Minist&egrave;re de la femme, la LTDH, l&rsquo;ATPDH, l&rsquo;AET et le CNJT qui ont r&eacute;pondu positivement en mettant &agrave; la disposition du projet des personnes capables de r&eacute;aliser cette activit&eacute;. Deux assistants dans 22 provinces et cinq &agrave; N&rsquo;Djamena seront donc d&eacute;ploy&eacute;s sur le terrain pour la collecte mensuelle des donn&eacute;es&nbsp;&raquo;</em>. </span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le coordonnateur a saisi l&rsquo;occasion pour faire un</span></span><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\"> rappel sur le projet ainsi que sur l&rsquo;Observatoire. Il a soulign&eacute; que &laquo;&nbsp;<em>le projet de mise en place de l&rsquo;Observatoire est f<strong>inanc&eacute; par l&rsquo;Union Europ&eacute;enne &agrave; travers le Projet d&rsquo;Appui &agrave; l&rsquo;Am&eacute;lioration de la S&eacute;curit&eacute; Int&eacute;rieure au Tchad (PAASIT). </strong>L&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re au Tchad (OVPCDP) qui a &eacute;t&eacute; cr&eacute;&eacute; par la loi <strong>N&deg;042/PR/2019 du 19 d&eacute;cembre 2019</strong> a pour missions de collecter, d&rsquo;analyser et de produire de l&rsquo;information en mati&egrave;re d&rsquo;incivilit&eacute;, d&rsquo;infractions, des d&eacute;lits, de crimes et de toutes formes de violence et de d&eacute;viance ainsi que la r&eacute;gulation sociale de la violence.&nbsp;&raquo;</em></span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Senoussi Hassana Abdoulaye a demand&eacute; aux participants de suivre avec attention la formation th&eacute;orique et pratique qui leur sera donn&eacute;e par les membres de l&rsquo;&eacute;quipe du projet. </span></span><span style=\"font-size:13.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">A la fin de la formation, tous les assistants chercheurs ont sign&eacute; un contrat les liant au Consortium pour une dur&eacute;e de six (6) mois. </span></span></span></span></p>', 'https://observatoire-td.org/observer/public/images/actualites/formation-1582704741_1664278678.png', '2022-09-27 16:37:58', '2022-09-27 16:37:58', 42, NULL),
(46, 'TERMES DE RÉFÉRENCE POUR LE RECRUTEMENT', 'ANNEXE II : TERMES DE RÉFÉRENCE\r\nPOUR LE RECRUTEMENT D’UN CONSULTANT INDIVIDUEL OU CABINET EN ELABORATION DE DOCUMENTS ADMINISTRATIFS ET FINANCIERS', '<p style=\"text-align:center\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">ANNEXE II : TERMES DE R&Eacute;F&Eacute;RENCE</span></span></strong></span></span></p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">POUR LE RECRUTEMENT D&rsquo;UN CONSULTANT INDIVIDUEL OU CABINET <a name=\"_Hlk115350029\">EN ELABORATION DE DOCUMENTS ADMINISTRATIFS ET FINANCIERS</a></span></span></strong></span></span></p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\">&nbsp;</p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Consortium ENA-CERGIED-CRASH, dans le cadre du projet &laquo;&nbsp;Appui &agrave; la mise en place et au d&eacute;veloppement de l&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re (OVPCDP)&nbsp;&raquo; recrute un (e) Consultant (e) individuel ou un cabinet charg&eacute; (e) d&rsquo;&eacute;laborer les textes administratifs et financiers de l&rsquo;OVPCDP. </span></span></strong></span></span></p>', 'https://observatoire-td.org/observer/public/images/actualites/TDR1-1343221870_1665577587.png', '2022-10-12 17:26:27', '2022-10-12 17:26:27', 42, NULL),
(47, 'TERMES DE RÉFÉRENCE  POUR LE RECRUTEMENT.', 'ANNEXE II : TERMES DE RÉFÉRENCE\r\nPOUR LE RECRUTEMENT D’UN EXPERT EN CONCEPTION ET OPERATIONNALISATION DES OBSERVATOIRES', '<p style=\"text-align:center\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">ANNEXE II : TERMES DE R&Eacute;F&Eacute;RENCE</span></span></strong></span></span></p>\r\n\r\n<p style=\"text-align:center\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">POUR LE RECRUTEMENT D&rsquo;UN EXPERT EN CONCEPTION ET OPERATIONNALISATION DES OBSERVATOIRES</span></span></strong></span></span>​​​​​​​</p>\r\n\r\n<p><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Consortium ENA-CERGIED-CRASH, dans le cadre du projet &laquo;&nbsp;Appui &agrave; la mise en place et au d&eacute;veloppement de l&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re (OVPCDP)&nbsp;&raquo; recrute un (e) Consultant (e) charg&eacute; (e) d&rsquo;appuyer la mise en place et le d&eacute;veloppement de l&rsquo;OVPCDP.</span></span></strong></p>', 'https://observatoire-td.org/observer/public/images/actualites/TDR1-209979151_1665650341.png', '2022-10-13 13:39:01', '2022-10-13 13:39:01', 42, NULL),
(48, 'TERMES DE RÉFÉRENCE POUR LE RECRUTEMENT', 'ANNEXE II : TERMES DE RÉFÉRENCE POUR LE RECRUTEMENT D’UN EXPERT NATIONAL EN GESTION DE BASE DE DONNEES.', '<p style=\"text-align:center\"><span style=\"font-size:12pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">ANNEXE II : TERMES DE R&Eacute;F&Eacute;RENCE POUR LE RECRUTEMENT D&rsquo;UN </span></span></strong><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">EXPERT NATIONAL EN GESTION DE BASE DE DONNEES</span></span></strong></span></span>​​​​​​</p>\r\n\r\n<p><strong><span style=\"font-size:14.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Consortium ENA-CERGIED-CRASH, dans le cadre du projet &laquo;&nbsp;Appui &agrave; la mise en place et au d&eacute;veloppement de l&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re (OVPCDP)&nbsp;&raquo; recrute un (e) Consultant (e) charg&eacute; (e) d&rsquo;appuyer le d&eacute;veloppement de la base de donn&eacute;es de l&rsquo;OVPCDP. </span></span></strong></p>', 'https://observatoire-td.org/observer/public/images/actualites/TDR1-1138073152_1665650660.png', '2022-10-13 13:44:20', '2022-10-13 13:44:20', 42, NULL),
(49, 'FOCUS SUR LES ORGANES DE L’OBSERVATOIRE', 'L’Observatoire de la Violence, de la Prévention de la Criminalité et de la Déontologie Policière (OVPCDP) a été créé par la loi N°049/PR/2019 du 19 décembre 2019. Le Décret N°1944/PR/MSPI/2020 du 22 septembre 2020 a ensuite fixé le cadre juridique et déterminer les modalités de l’organisation et du fonctionnement de cette institution.', '<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">L&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re (OVPCDP) a &eacute;t&eacute; cr&eacute;&eacute; par la loi N&deg;049/PR/2019 du 19 d&eacute;cembre 2019. Le D&eacute;cret N&deg;1944/PR/MSPI/2020 du 22 septembre 2020 a ensuite fix&eacute; le cadre juridique et d&eacute;terminer les modalit&eacute;s de l&rsquo;organisation et du fonctionnement de cette institution.</span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">La Loi pr&eacute;cise que L&#39;OVPCDP&nbsp;est :</span></span></span></span></p>\r\n\r\n<ul>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">un &eacute;tablissement Public &agrave; caract&egrave;re administratif et &agrave; vocation technique et scientifique, dot&eacute; de la personnalit&eacute; juridique et de l&#39;autonomie de gestion ;</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">plac&eacute; sous la supervision du Minist&egrave;re en charge de la S&eacute;curit&eacute; Publique ; </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">charg&eacute; de collecter, d&#39;analyser et de produire de l&#39;information en mati&egrave;re d&#39;incivilit&eacute;, d&rsquo;infractions, des d&eacute;lits, de crimes et de toutes formes de violence et de d&eacute;viances ainsi que la r&eacute;gulation sociale de la violence ; </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">structur&eacute; autour d&#39;un dispositif institutionnel comprenant : un Comit&eacute; de Pilotage, une Cellule de Gestion, un Comit&eacute; Scientifique.</span></span></span></span></li>\r\n</ul>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Comit&eacute; de Pilotage qui est l&#39;organe d&#39;orientation strat&eacute;gique et de d&eacute;cision de I&#39;OVPCDP a pour&nbsp; missions essentielles de superviser et valider les orientations strat&eacute;giques des travaux de l&#39;observatoire, examiner et approuver le Plan de travail et le budget annuel, examiner et approuver les rapports d&#39;activit&eacute;s.</span></span></span></span></p>\r\n\r\n<p style=\"margin-left:-28px; margin-right:-9px; text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Comit&eacute; de Pilotage est compos&eacute; d&rsquo;un Pr&eacute;sident, en la personne du Ministre en charge de la&nbsp; S&eacute;curit&eacute; Publique, d&rsquo;un Vice-pr&eacute;sident : Le Ministre Secr&eacute;taire G&eacute;n&eacute;ral du Gouvernement&nbsp;et de plusieurs membres &agrave; savoir&nbsp;:</span></span></span></span></p>\r\n\r\n<ul style=\"list-style-type:square\">\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge du Plan</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de la Justice, </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de la l&#39;Am&eacute;nagement du Territoire, </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de l&rsquo;Administration du Territoire, </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de l&rsquo;Enseignement Sup&eacute;rieur,</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de l&rsquo;Education Nationale</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de la Femme</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge des finances et du budget, </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Ministre en charge de l&rsquo;environnement,</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Pr&eacute;sident de la Commission Nationale des Droits de l&#39;Homme (CNDH); </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Directeur G&eacute;n&eacute;ral du Centre&nbsp; National d&#39;Appui &agrave; la Recherche (CNRD), </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Pr&eacute;sident de l&#39; Universit&eacute; de N&#39;Djamena. </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Les repr&eacute;sentants des Partenaires Techniques et Financiers (PTF) assistent aux r&eacute;unions du Comit&eacute; de Pilotage sans voix d&eacute;lib&eacute;rative. </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Secr&eacute;tariat du Comit&eacute; de Pilotage est assur&eacute; par le Coordonnateur de la Cellule de Gestion de l&rsquo;Observatoire. </span></span></span></span></li>\r\n</ul>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><em><u><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Comit&eacute; Scientifique&nbsp;:</span></span></u></em></strong></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Comit&eacute; Scientifique est constitu&eacute; de chercheurs de haut niveau et est charg&eacute; de la formulation, de la validation, du contr&ocirc;le des programmes d&rsquo;&eacute;tude et de recherche, de la s&eacute;lection des r&eacute;sultats m&eacute;ritant diffusion, de l&rsquo;orientation des analystes sur le plan m&eacute;thodologique ainsi que de l&rsquo;adoption d&rsquo;un plan de formation des analystes de l&rsquo;Observatoire. Conform&eacute;ment au D&eacute;cret N&deg; 1944/PR/MSPI/2020, cet organe est&nbsp;compos&eacute; comme suit&nbsp;: </span></span></span></span></p>\r\n\r\n<ul style=\"list-style-type:square\">\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Pr&eacute;sident, le Directeur en charge de la Recherche &agrave; l&rsquo;ENA. </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Membres&nbsp;: Des chercheurs de haut rang d&eacute;sign&eacute;s selon des crit&egrave;res d&eacute;finis par le Comit&eacute; de Pilotage pour une dur&eacute;e de deux ans renouvelables. Le Comit&eacute; Scientifique doit comprendre en son sein, des femmes. Le nombre des Chercheurs cit&eacute;s ci-dessus ne doit pas exc&eacute;der dix (10) personnes.</span></span></span></span></li>\r\n</ul>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Il comprend en outre, des membres observateurs, compos&eacute;s comme suit&nbsp;: </span></span></span></span></p>\r\n\r\n<ul style=\"list-style-type:square\">\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">un repr&eacute;sentant des organisations f&eacute;minines&nbsp;; </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">un repr&eacute;sentant des organisations des Jeunes ;</span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">un repr&eacute;sentant des organisations de d&eacute;fense des Droits de l&#39;Homme ; </span></span></span></span></li>\r\n	<li style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">un repr&eacute;sentant des confessions religieuses. (Les membres ci-dessus sont d&eacute;sign&eacute;s par leurs institutions respectives pour une dur&eacute;e de deux ans, renouvelable).</span></span></span></span></li>\r\n</ul>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Le Comit&eacute; Scientifique de L&#39;OVPCDP a pour mission de veiller &agrave; la collecte, la centralisation et l&rsquo;actualisation de toute la documentation scientifique et technique d&#39;origine nationale ou &eacute;trang&egrave;re dans les champs qui concernent l&rsquo;institution, et pourvoir &agrave; sa diffusion dans les milieux concern&eacute;s. Le Comit&eacute; Scientifique doit aussi s&rsquo;assurer que les donn&eacute;es relatives &agrave; son champ de comp&eacute;tence soient conserv&eacute;es et diss&eacute;min&eacute;es. Il doit aussi encadrer la r&eacute;alisation des &eacute;tudes, recherches scientifiques et techniques dans ses champs de comp&eacute;tence et veiller &agrave; l&rsquo;animation des milieux professionnels et scientifiques&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &agrave;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; travers des conf&eacute;rences et colloques en vue de favoriser les &eacute;changes ainsi que de soutenir les capacit&eacute;s de collecte et traitement de l&#39;information. &nbsp;&nbsp;&nbsp;</span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Aussi, le Comit&eacute; Scientifique doit s&rsquo;assurer que l&rsquo;OVPCDP contribue, par sa production, au d&eacute;veloppement des organisations du secteur, &agrave; l&#39;enseignement dispens&eacute; dans les &eacute;tablissements universitaires et la formation professionnelle.</span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Pour finir, le Comit&eacute; est aussi charg&eacute; de formuler les programmes d&#39;&eacute;tudes et de recherche ainsi que d&rsquo;assurer la formation des Chercheurs sur le plan m&eacute;thodologique.</span></span></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><strong><em><u><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">La cellule de gestion&nbsp;:</span></span></u></em></strong></span></span></p>\r\n\r\n<p style=\"text-align:justify\"><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">&nbsp;La cellule de gestion&nbsp;est un organe qui s&rsquo;occupe de la gestion courante de I&rsquo;OVPCDP. Elle a pour mission g&eacute;n&eacute;rale de veiller au suivi des d&eacute;cisions du Comit&eacute; de Pilotage et d&#39;assurer la bonne circulation de l&#39;information entre tous les membres. A ce titre, elle est charg&eacute;e de :</span></span></span></span></p>\r\n\r\n<ul style=\"list-style-type:square\">\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">mobiliser des &eacute;quipes de chercheurs et de formateurs comp&eacute;tents en mati&egrave;re de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re ;&nbsp;&nbsp; </span></span></span></span></li>\r\n</ul>\r\n\r\n<ul style=\"list-style-type:square\">\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">fournir au d&eacute;but de chaque ann&eacute;e en m&ecirc;me temps qu&#39;un rapport, un programme d&#39;activit&eacute;s pr&eacute;cisant les travaux envisag&eacute;s, le planning de travail, les moyens humains, financiers et mat&eacute;riels pr&eacute;vus ;&nbsp;&nbsp;&nbsp; </span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">fournir au Comit&eacute; de Pilotage, les rapports semestriels d&#39;ex&eacute;cution ;&nbsp; </span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Organiser la circulation l&#39;information en mettant en place une base de donn&eacute;es fiables ;</span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">travailler en &eacute;troite collaboration avec toutes les institutions pertinentes au regard de son champ de comp&eacute;tence.</span></span></span></span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">La Cellule de Gestion de I&#39;OVPCDP dispose d&#39;un personnel technique et administratif compos&eacute; comme suit&nbsp;:</span></span></span></span></p>\r\n\r\n<ul style=\"list-style-type:square\">\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Financier ;</span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Un Sp&eacute;cialiste en Passation des March&eacute;s ;</span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Un Sp&eacute;cialiste Syst&egrave;me d&rsquo;Information&nbsp;;</span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Un Sp&eacute;cialiste en Suivi et Evaluation ;&nbsp;&nbsp; </span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Un Charg&eacute; de Communication ;</span></span></span></span></li>\r\n	<li><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">Un Personnel Technique d&rsquo;Appui.</span></span></span></span></li>\r\n</ul>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">La Cellule de Gestion est coordonn&eacute;e par le Directeur G&eacute;n&eacute;ral de l&rsquo;ENA.</span></span></span></span></p>\r\n\r\n<p><span style=\"font-size:11pt\"><span style=\"font-family:Calibri,sans-serif\"><span style=\"font-size:12.0pt\"><span style=\"font-family:&quot;Times New Roman&quot;,serif\">La cellule de gestion n&rsquo;existe pas encore. Elle sera le dernier organe de l&rsquo;OVPCDP mis en place par le projet.</span></span></span></span></p>', 'https://observatoire-td.org/observer/public/images/actualites/observatoire-1096372657_1666089407.png', '2022-10-18 15:36:47', '2022-10-18 15:36:47', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `user_profile` varchar(500) DEFAULT NULL,
  `password` varchar(155) NOT NULL,
  `status` varchar(30) NOT NULL DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '1',
  `super_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `gender`, `email`, `phone`, `user_profile`, `password`, `status`, `created_at`, `updated_at`, `role_id`, `super_id`) VALUES
(34, 'Frederic Bangadinga', 'male', 'frederic@gmail.com', '+23560286069', 'http://localhost/lab/observer/public/images/users/profile.jpeg', '$2y$10$xzgL.SBKuIEzZvhUsBofR.o.84kfgMHhUbt.d19ppwd3AA98LbtIq', 'Active', '2022-09-03 19:43:36', '2022-09-03 19:43:36', 1, 37),
(35, 'Khalil Hisseine', 'male', 'khalil@hltic.org', '+23566200135', 'http://localhost/lab/observer/public/images/users/pic01-379264576_1657634706.jpg', '$2y$10$J5VtTGjMd3Ffmwa2h1OFAue14qKTjvxoizEzpZcCsp8FR4Y1shMwq', 'Active', '2022-07-13 17:44:49', '2022-07-13 17:44:49', 1, 39),
(38, 'Halime Khalil Hisseine', 'Femme', 'halime@hltic.org', '+23566300335', 'http://localhost/lab/observer/public/images/users/profile.jpeg', '$2y$10$s.mN1q76b/MKkroFsSTjBexWRd2KkB73zFSUaIzL3WlD7CO77xXty', 'Active', '2022-07-10 14:02:17', '2022-07-10 14:02:17', 1, 35),
(40, 'Hamdane Khalil Hisseine', 'Homme', 'hamdane@hltic.org', '+23566300135', 'http://localhost/lab/observer/public/images/users/profile.png', '$2y$10$SCIika3VuLvjonYetZVKeeUO09BgF2VRob2l1OsmoeJg46aH3EzM6', 'Active', '2022-09-03 19:46:05', '2022-09-03 19:46:05', 1, 38),
(41, 'Aicha Khalil Hisseine', 'Femme', 'aicha@hltic.org', '+23566500135', 'http://localhost/lab/observer/public/images/users/profile.jpeg', '$2y$10$A.Y8w2dFiF3mFKjzHR45OOqRxZOlLriDHkVf9S2zRVdqm6npu6KrC', 'Desactive', '2022-07-11 20:11:03', '2022-07-11 20:11:03', 1, 40),
(42, 'Steve Nanoudjal', 'Homme', 'stevenanoudjal@gmail.com', '65746727', 'https://observatoire-td.org/observer/public/images/users/profile.jpeg', '$2y$10$qK.BjhrimJ77N94xQskTA.1q/qtm4V2DiUm0jW2RUSQ336OpK6Y2K', 'Active', '2022-09-20 11:39:47', '2022-09-20 11:39:47', 1, 34);

-- --------------------------------------------------------

--
-- Table structure for table `autoritesaisies`
--

CREATE TABLE `autoritesaisies` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(255) NOT NULL,
  `abilite_recevoire_plainte` varchar(255) NOT NULL,
  `abilite_recevoire_denociation` varchar(255) NOT NULL,
  `abilite_ouvrir_enquete` varchar(255) NOT NULL,
  `sys_judiciare_appartenance` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `autoritesaisies`
--

INSERT INTO `autoritesaisies` (`id`, `titre`, `abilite_recevoire_plainte`, `abilite_recevoire_denociation`, `abilite_ouvrir_enquete`, `sys_judiciare_appartenance`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(4, 'Administrative', 'NON', 'NON', 'NON', 'RAS', '2022-09-20 17:26:37', '2022-09-20 17:26:37', 42, NULL),
(7, 'Commissariat', 'NON', 'OUI', 'NON', 'Extra judiciaire', '2022-09-29 14:02:56', '2022-09-29 14:02:56', 35, NULL),
(8, 'Brigade', 'OUI', 'NON', 'OUI', 'Extra judiciaire', '2022-09-29 14:03:36', '2022-09-29 14:03:36', 35, NULL),
(9, 'Brigade', 'OUI', 'NON', 'OUI', 'Extra judiciaire', '2022-09-29 14:03:46', '2022-09-29 14:03:46', 35, NULL),
(11, 'N/A', 'NON', 'NON', 'OUI', 'N/A', '2022-10-09 04:03:23', '2022-10-09 04:03:23', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `categorieprofessionels`
--

CREATE TABLE `categorieprofessionels` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle_cat` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `decision_finals`
--

CREATE TABLE `decision_finals` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `decision_finals`
--

INSERT INTO `decision_finals` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'Règlement a  l\'amiable', '2022-09-16 12:02:01', '2022-09-16 12:02:01', 35, NULL),
(2, 'Autre', '2022-09-16 12:02:31', '2022-09-16 12:02:31', 35, NULL),
(3, 'RAS', '2022-09-20 17:43:45', '2022-09-20 17:43:45', 42, NULL),
(4, 'Condamnation', '2022-09-20 17:44:50', '2022-09-20 17:44:50', 42, NULL),
(5, 'N/A', '2022-10-09 04:03:46', '2022-10-09 04:03:46', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `enquetes`
--

CREATE TABLE `enquetes` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(400) NOT NULL,
  `slag` text NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(400) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `etat_decisions`
--

CREATE TABLE `etat_decisions` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_decifinal` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_decisions`
--

INSERT INTO `etat_decisions` (`id`, `id_decifinal`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 1, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 3, 1, '2022-09-27 17:33:45', '2022-09-27 17:33:45', 42, NULL),
(3, 1, 4, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_denonciations`
--

CREATE TABLE `etat_denonciations` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_autosaisie` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_denonciations`
--

INSERT INTO `etat_denonciations` (`id`, `id_autosaisie`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 1, 2, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 2, 4, '2022-09-27 17:09:45', '2022-09-27 17:09:45', 42, NULL),
(3, 1, 4, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_enqtes`
--

CREATE TABLE `etat_enqtes` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_enqte` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `id_autosaisie` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_enqtes`
--

INSERT INTO `etat_enqtes` (`id`, `id_enqte`, `id_etat_infra`, `id_autosaisie`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 1, 1, 2, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 1, 2, 4, '2022-09-27 17:09:45', '2022-09-27 17:09:45', 42, NULL),
(3, 1, 1, 4, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_gardeavues`
--

CREATE TABLE `etat_gardeavues` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_gardeavue` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_gardeavues`
--

INSERT INTO `etat_gardeavues` (`id`, `id_gardeavue`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 1, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 5, 2, '2022-09-27 17:09:45', '2022-09-27 17:09:45', 42, NULL),
(3, 4, 3, '2022-09-27 17:33:45', '2022-09-27 17:33:45', 42, NULL),
(4, 3, 1, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL),
(5, 7, 3, '2022-10-12 18:11:21', '2022-10-12 18:11:21', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_infra_jours`
--

CREATE TABLE `etat_infra_jours` (
  `id` int(10) UNSIGNED NOT NULL,
  `date_infra` varchar(155) NOT NULL,
  `id_infra` int(10) UNSIGNED DEFAULT NULL,
  `etat_denonciation` tinyint(1) DEFAULT NULL,
  `id_autho` int(10) UNSIGNED DEFAULT NULL,
  `etat_decision_final` tinyint(1) DEFAULT NULL,
  `id_decision` int(10) UNSIGNED DEFAULT NULL,
  `etat_enquette` tinyint(1) DEFAULT NULL,
  `id_enqt` int(10) UNSIGNED DEFAULT NULL,
  `etat_garde_avue` tinyint(1) DEFAULT NULL,
  `id_gravue` int(10) UNSIGNED DEFAULT NULL,
  `etat_non_enqte` tinyint(1) DEFAULT NULL,
  `id_neqte` int(10) UNSIGNED DEFAULT NULL,
  `etat_satisfaction` tinyint(1) DEFAULT NULL,
  `id_satisfact` int(10) UNSIGNED DEFAULT NULL,
  `etat_source_judiciaire` tinyint(1) DEFAULT NULL,
  `id_judiciaire` int(10) UNSIGNED DEFAULT NULL,
  `etat_source_osc` tinyint(1) DEFAULT NULL,
  `id_osc` int(10) UNSIGNED DEFAULT NULL,
  `etat_media_source` tinyint(1) DEFAULT NULL,
  `id_media` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL,
  `id_tinfra` int(10) UNSIGNED DEFAULT NULL,
  `id_victime` int(10) UNSIGNED DEFAULT NULL,
  `id_age` int(10) UNSIGNED DEFAULT NULL,
  `id_province` int(10) UNSIGNED DEFAULT NULL,
  `id_lieu_infra` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_infra_jours`
--

INSERT INTO `etat_infra_jours` (`id`, `date_infra`, `id_infra`, `etat_denonciation`, `id_autho`, `etat_decision_final`, `id_decision`, `etat_enquette`, `id_enqt`, `etat_garde_avue`, `id_gravue`, `etat_non_enqte`, `id_neqte`, `etat_satisfaction`, `id_satisfact`, `etat_source_judiciaire`, `id_judiciaire`, `etat_source_osc`, `id_osc`, `etat_media_source`, `id_media`, `created_at`, `updated_at`, `admin_id`, `super_id`, `id_tinfra`, `id_victime`, `id_age`, `id_province`, `id_lieu_infra`) VALUES
(2, '2022-10-09', 6, 0, 11, 0, 5, 0, 2, 0, 6, 0, 3, 0, 4, 0, 4, 0, 3, 0, 41, '2022-10-09 04:10:45', '2022-10-09 04:10:45', 35, NULL, 1, 1, 3, 19, 4),
(3, '2022-05-25', 8, 0, 11, 0, 5, 0, 2, 1, 7, 0, 3, 0, 4, 0, 4, 0, 3, 0, 41, '2022-10-12 18:11:21', '2022-10-12 18:11:21', 42, NULL, 2, 1, 3, 1, 4);

-- --------------------------------------------------------

--
-- Table structure for table `etat_judiciaires`
--

CREATE TABLE `etat_judiciaires` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_judiciaire` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_judiciaires`
--

INSERT INTO `etat_judiciaires` (`id`, `id_judiciaire`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 3, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 3, 1, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_media_sources`
--

CREATE TABLE `etat_media_sources` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_media_source` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_media_sources`
--

INSERT INTO `etat_media_sources` (`id`, `id_media_source`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 40, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 40, 1, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_non_enqtes`
--

CREATE TABLE `etat_non_enqtes` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_rsnon_enqte` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_non_enqtes`
--

INSERT INTO `etat_non_enqtes` (`id`, `id_rsnon_enqte`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(6, 1, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(7, 2, 1, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_oscs`
--

CREATE TABLE `etat_oscs` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_osc` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_oscs`
--

INSERT INTO `etat_oscs` (`id`, `id_osc`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 2, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 2, 1, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `etat_satisfactions`
--

CREATE TABLE `etat_satisfactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_satifaction` int(10) UNSIGNED NOT NULL,
  `id_etat_infra` int(10) UNSIGNED NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `etat_satisfactions`
--

INSERT INTO `etat_satisfactions` (`id`, `id_satifaction`, `id_etat_infra`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 1, 1, '2022-09-20 12:54:50', '2022-09-20 12:54:50', 35, NULL),
(2, 2, 3, '2022-09-27 17:33:45', '2022-09-27 17:33:45', 42, NULL),
(3, 2, 1, '2022-10-03 14:17:54', '2022-10-03 14:17:54', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `fsis`
--

CREATE TABLE `fsis` (
  `id` int(10) UNSIGNED NOT NULL,
  `struct_securitaire` varchar(200) NOT NULL,
  `type_post` varchar(200) NOT NULL,
  `fonction_fsi` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `galleries`
--

CREATE TABLE `galleries` (
  `id` int(10) UNSIGNED NOT NULL,
  `imgurl` varchar(500) NOT NULL,
  `imgalt` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `gerdeavues`
--

CREATE TABLE `gerdeavues` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `gerdeavues`
--

INSERT INTO `gerdeavues` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(3, '48.0', '2022-09-20 17:30:29', '2022-09-20 17:30:29', 42, NULL),
(4, '1.0', '2022-09-20 17:32:15', '2022-09-20 17:32:15', 42, NULL),
(5, '72.0', '2022-09-20 17:36:16', '2022-09-20 17:36:16', 42, NULL),
(6, 'N/A', '2022-10-09 04:04:45', '2022-10-09 04:04:45', 35, NULL),
(7, '12.0', '2022-10-12 18:06:47', '2022-10-12 18:06:47', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `infractions`
--

CREATE TABLE `infractions` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle_inf` text NOT NULL,
  `date` datetime DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL,
  `type_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `infractions`
--

INSERT INTO `infractions` (`id`, `libelle_inf`, `date`, `created_at`, `updated_at`, `admin_id`, `super_id`, `type_id`) VALUES
(5, 'Harcèlement en milieu scolaire', '2022-05-25 00:00:00', '2022-09-20 17:06:02', '2022-09-20 17:06:02', 42, NULL, 2),
(6, 'Braquage des motos', '2022-05-30 00:00:00', '2022-09-20 17:07:19', '2022-09-20 17:07:19', 42, NULL, 1),
(7, 'Bagarre rangée', '2022-06-01 00:00:00', '2022-09-20 17:08:01', '2022-09-20 17:08:01', 42, NULL, 2),
(8, 'Vol de betails', '2022-05-25 00:00:00', '2022-10-12 18:03:26', '2022-10-12 18:03:26', 42, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `infras_imports`
--

CREATE TABLE `infras_imports` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` date DEFAULT NULL,
  `localite` varchar(100) DEFAULT NULL,
  `province` varchar(50) DEFAULT NULL,
  `type_infraction` varchar(100) DEFAULT NULL,
  `infractions` varchar(200) DEFAULT NULL,
  `consquence` varchar(200) DEFAULT NULL,
  `source_information` varchar(100) DEFAULT NULL,
  `nom_media` varchar(100) DEFAULT NULL,
  `nom_osc` varchar(100) DEFAULT NULL,
  `nationalite` varchar(100) DEFAULT NULL,
  `genre` varchar(30) DEFAULT NULL,
  `categorie_prof` varchar(100) DEFAULT NULL,
  `tranche_age` varchar(30) DEFAULT NULL,
  `denonciation_verbale` varchar(255) DEFAULT NULL,
  `autorite_saisie` varchar(100) DEFAULT NULL,
  `plainte` varchar(100) DEFAULT NULL,
  `non_pourquoi` varchar(100) DEFAULT NULL,
  `enquete` varchar(40) DEFAULT NULL,
  `type_enquete` varchar(100) DEFAULT NULL,
  `diligente_par` varchar(100) DEFAULT NULL,
  `garde_vue` varchar(100) DEFAULT NULL,
  `duree_garde_vue` varchar(30) DEFAULT NULL,
  `jugement` varchar(40) DEFAULT NULL,
  `systeme_judiciaire` varchar(50) DEFAULT NULL,
  `etat_decision` varchar(50) DEFAULT NULL,
  `satisfait` varchar(100) DEFAULT NULL,
  `pourquoi_non_satisfait` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `lieu_infras`
--

CREATE TABLE `lieu_infras` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL,
  `infra_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `lieu_infras`
--

INSERT INTO `lieu_infras` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`, `infra_id`) VALUES
(4, 'Zone urbaine', '2022-09-20 17:14:35', '2022-09-20 17:14:35', 42, NULL, 6),
(5, 'A l\'école', '2022-09-20 17:17:50', '2022-09-20 17:17:50', 42, NULL, 5);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `oscs`
--

CREATE TABLE `oscs` (
  `id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `date` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `oscs`
--

INSERT INTO `oscs` (`id`, `nom`, `description`, `date`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'CMT', 'Coordination des motos taxis', '2022-09-19', '2022-09-19 13:42:18', '2022-09-19 13:42:18', 35, NULL),
(2, 'GJB', 'Groupe des jeunes Bardaï', '2022-09-19', '2022-09-19 13:42:49', '2022-09-19 13:42:49', 35, NULL),
(3, 'N/A', 'N/A', '2022-10-09', '2022-10-09 04:08:38', '2022-10-09 04:08:38', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `partenaires`
--

CREATE TABLE `partenaires` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(500) NOT NULL,
  `link` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `partenaires`
--

INSERT INTO `partenaires` (`id`, `name`, `description`, `imgurl`, `link`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'L’Ecole Nationale d’Administration', 'Créée en 1963, l’ENA est un établissement public, à caractère administratif, doté de la personnalité morale et de l’autonomie de gestion. Sa principale mission est d’assurer la formation initiale, le recyclage et le perfectionnement des agents de l’Etat. En plus de cette mission, l’ENA conduit des activités recherches-actions en sciences administratives et management public. C’est à ce titre qu’elle a été choisie pour abriter l’Observatoire de la Violence, de la Prévention de la Criminalité et de la Déontologie Policière, conformément à l’Article 3 de la Loi N° 042/PR/2019 Portant création d’un Observatoire de la Violence, de la Prévention de la Criminalité et de la Déontologie Policière.\r\nDans le cadre de cette action, elle est le Chef de file du Consortium et s’occupe de la coordination générale de la mise en œuvre de toutes activités ainsi que de la bonne collaboration avec les autres parties prenantes.', 'https://observatoire-td.org/observer/public/images/partenaires/ENAlogo-582304573_1665578033.png', 'https://www.ena.td/fr', '2022-10-12 17:33:53', '2022-10-12 17:33:53', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `partener02s`
--

CREATE TABLE `partener02s` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(300) NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(500) NOT NULL,
  `link` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `partener02s`
--

INSERT INTO `partener02s` (`id`, `name`, `description`, `imgurl`, `link`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'Le Centre d’Etudes et de Recherches sur la Gouvernance, les Industries Extractives et le Développement Durable', 'Le CERGIED est un Centre de recherche et de gouvernance spécialisé dans les politiques publiques inclusives et la participation citoyenne depuis bientôt vingt ans. Le CERGIED est présent sur le terrain dans 17 provinces du Tchad à travers ses Organisations Communautaires de Base. Il est codemandeur dans le cadre de l’action et donc contribue à la mise en œuvre des activités.', 'https://observatoire-td.org/observer/public/images/partenaires/cergied-1842283423_1665578421.png', 'undefined', '2022-10-12 17:40:21', '2022-10-12 17:40:21', 42, NULL),
(2, 'Le Centre de Recherches en Anthropologie et Sciences Humaines', ': le CRASH est un laboratoire de recherches pluridisciplinaires qui a pour but de promouvoir la recherche en anthropologie et sciences humaines pour le développement du Tchad. Il est né du partenariat entre plusieurs chercheurs du Tchad et d’ailleurs, ayant en commun la pratique d’études sur différentes problématiques relatives au Tchad et la volonté de voir avancer la recherche scientifique au niveau local. \r\nEn tant que codemandeur, le CRASH participe à la mise en œuvre de l’ensemble des activités du projet, conformément au cahier des charges.', 'https://observatoire-td.org/observer/public/images/partenaires/crash-133399129_1665578699.png', 'undefined', '2022-10-12 17:44:59', '2022-10-12 17:44:59', 42, NULL),
(3, 'L’Union européenne (UE)', 'Issue de la Communauté économique européenne (CEE) créée en 1957, l\'Union européenne (UE) compte aujourd\'hui 27 Etats membres. Elle constitue une organisation sans aucun équivalent dans le monde.\r\nOrganisation unique dans le monde, l’Union européenne rassemble aujourd’hui 27 Etats membres. Ceux-ci ont décidé de mettre en commun une partie de leur souveraineté, d’abord pour reconstruire leur économie au sortir de la Seconde Guerre mondiale et favoriser la paix entre eux, puis peu à peu pour répondre à d’autres défis.\r\nDe l’alimentation à la circulation des personnes en passant par la monnaie, l’environnement ou le numérique, l’Union européenne agit sur tous les fronts. Elle le fait en complément des politiques nationales, qu’elle oriente dans certains cas. \r\nL’Union se compose de plusieurs institutions, dont les plus connues sont la Commission, le Parlement, le Conseil de l’UE et le Conseil européen. Chacune, qui représente des intérêts différents, intervient dans les décisions européennes.', 'https://observatoire-td.org/observer/public/images/partenaires/union_europeenne-359135993_1665579019.png', 'https://european-union.europa.eu/index_fr', '2022-10-12 17:50:19', '2022-10-12 17:50:19', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `presentations`
--

CREATE TABLE `presentations` (
  `id` int(10) UNSIGNED NOT NULL,
  `titre` varchar(400) NOT NULL,
  `slag` text NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `presentations`
--

INSERT INTO `presentations` (`id`, `titre`, `slag`, `description`, `imgurl`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'OBSERVATOIRE DE LA VIOLENCE', 'Objectif Général : Contribuer à la réduction et à la dissipation du climat d’impunité et d’insécurité grâce à l\'offre de la sécurité comme un bien public de qualité, qui répond aux besoins des citoyens.\r\n OS1 : Appuyer la mise en place et le développement de l’Observatoire de la Violence, de la Prévention de la Criminalité et de la Déontologie Policière ;\r\nOS2 : Appuyer la production et la diffusion de l’information à travers la réalisation des études scientifiques indépendantes au profit de l’Etat, des institutions publiques et des partenaires privés sur les questions liées à la violence, à la prévention de la criminalité et à la déontologie policière ;\r\nOS3 : Renforcer la gouvernance sécuritaire grâce à l’offre des services et l’amélioration de la qualité des relations Forces de Sécurité Intérieure/citoyens.', '<p>PROJET&nbsp;D&rsquo;APPUI &Agrave; LA MISE EN PLACE ET AU D&Eacute;VELOPPEMENT DE L&rsquo;OBSERVATOIRE DE LA VIOLENCE, DE LA PR&Eacute;VENTION DE LA CRIMINALIT&Eacute; ET DE LA D&Eacute;ONTOLOGIE POLICI&Egrave;RE (PA-OVPCDP)</p>\r\n\r\n<p>Contrat de subvention n&deg; FED/2021/426-903</p>\r\n\r\n<p>Financement&nbsp;: Union Europ&eacute;enne (UE) &agrave; travers le Projet d&rsquo;Appui &agrave; l&rsquo;Am&eacute;lioration de la S&eacute;curit&eacute; Int&eacute;rieure au Tchad (PAASIT)&nbsp;</p>\r\n\r\n<p><br />\r\nPartenaires de mise en &oelig;uvre&nbsp;: consortium ENA-CERGIED-CRASH</p>\r\n\r\n<p>Financ&eacute; par l&rsquo;Union Europ&eacute;enne &agrave; travers le Projet d&rsquo;Appui &agrave; l&rsquo;Am&eacute;lioration de la S&eacute;curit&eacute; Int&eacute;rieure au Tchad (PAASIT), le projet a pour objet d&rsquo;apporter un appui &agrave; la mise en place et au d&eacute;veloppement de l&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re au Tchad (OVPCDP). Le consortium compos&eacute; de l&rsquo;&Eacute;cole Nationale d&rsquo;Administration (ENA), du Centre d&rsquo;&Eacute;tudes et de Recherches sur la Gouvernance, les Industries Extractives et le D&eacute;veloppement Durable&nbsp;(CERGIED) et du Centre de Recherches en Anthropologie et Sciences Humaines&nbsp;(CRASH) est le partenaire de mise en &oelig;uvre du projet N&deg;FED/2021/426-903.&nbsp;</p>\r\n\r\n<p>OBJECTIFS&nbsp;<br />\r\nObjectif G&eacute;n&eacute;ral&nbsp;: Contribuer &agrave; la r&eacute;duction et &agrave; la dissipation du climat d&rsquo;impunit&eacute; et d&rsquo;ins&eacute;curit&eacute; gr&acirc;ce &agrave; l&#39;offre de la s&eacute;curit&eacute; comme un bien public de qualit&eacute;, qui r&eacute;pond aux besoins des citoyens.<br />\r\n&nbsp;OS1 : Appuyer la mise en place et le d&eacute;veloppement de l&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re&nbsp;;<br />\r\nOS2 : Appuyer la production et la diffusion de l&rsquo;information &agrave; travers la r&eacute;alisation des &eacute;tudes scientifiques ind&eacute;pendantes au profit de l&rsquo;Etat, des institutions publiques et des partenaires priv&eacute;s sur les questions li&eacute;es &agrave; la violence, &agrave; la pr&eacute;vention de la criminalit&eacute; et &agrave; la d&eacute;ontologie polici&egrave;re&nbsp;;<br />\r\nOS3 : Renforcer la gouvernance s&eacute;curitaire gr&acirc;ce &agrave; l&rsquo;offre des services et l&rsquo;am&eacute;lioration de la qualit&eacute; des relations Forces de S&eacute;curit&eacute; Int&eacute;rieure/citoyens.&nbsp;</p>\r\n\r\n<p>RESULTATS ATTENDUS<br />\r\nR1&nbsp;: L&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re est mis en place et est fonctionnel&nbsp;;</p>\r\n\r\n<p>R2 : La production et la diffusion d&rsquo;une information ind&eacute;pendante sur les questions li&eacute;es &agrave; la violence, la d&eacute;linquance, la pr&eacute;vention de la criminalit&eacute; et la d&eacute;ontologie polici&egrave;re permet d&rsquo;am&eacute;liorer la situation s&eacute;curitaire au profit des citoyens&nbsp;;</p>\r\n\r\n<p>R3 : Le renforcement de la gouvernance s&eacute;curitaire a permis d&rsquo;am&eacute;liorer la qualit&eacute; des relations entre les Forces de S&eacute;curit&eacute; Int&eacute;rieure et les citoyens.</p>\r\n\r\n<p>Durant sa p&eacute;riode de mise en &oelig;uvre qui est de 15 mois, le projet pr&eacute;voit plusieurs activit&eacute;s notamment :&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;la mise en place d&rsquo;un r&eacute;seau de partenariat institutionnel pour la collecte des informations sur les questions de violence, de d&eacute;linquance, de criminalit&eacute; et de d&eacute;ontologie polici&egrave;re&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;la r&eacute;alisation de trois (03) &eacute;tudes th&eacute;matiques sur la violence et la criminalit&eacute;, l&rsquo;&eacute;thique et la d&eacute;ontologie polici&egrave;re et la gouvernance de la s&eacute;curit&eacute;&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;l&rsquo;octroi de huit (08) micros subventions &agrave; des centres de recherches et des chercheurs locaux&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;l&rsquo;organisation d&rsquo;un colloque international sur la gouvernance s&eacute;curitaire&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;l&rsquo;organisation de quatre (04) conf&eacute;rences) d&eacute;bats sur les th&egrave;mes de la violence, la lutte contre la criminalit&eacute;, la gouvernance locale de la s&eacute;curit&eacute;&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;la production, la diffusion de l&rsquo;information &agrave; travers les &eacute;tudes, les rapports d&rsquo;activit&eacute;s et les publications scientifiques (productions des donn&eacute;es statistiques et qualitatives, mise en place d&rsquo;une base de donn&eacute;es). &nbsp;</p>\r\n\r\n<p>B&eacute;n&eacute;ficiaires du projet&nbsp;:<br />\r\n⦁&nbsp;&nbsp; &nbsp;Les autorit&eacute;s &eacute;tatiques&nbsp;; &nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;les Forces de S&eacute;curit&eacute; Int&eacute;rieur (FSI)&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;les Organisations de la Soci&eacute;t&eacute; Civile (OSC)&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;les &eacute;l&egrave;ves et &eacute;tudiants&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;les leaders communautaires&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;les chercheurs.<br />\r\nParties prenantes&nbsp;:<br />\r\n⦁&nbsp;&nbsp; &nbsp;le PAASIT&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;l&rsquo;INSEED&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;le Minist&egrave;re en charge de la S&eacute;curit&eacute; Publique&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;le Secr&eacute;tariat G&eacute;n&eacute;ral du Gouvernement&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;Les m&eacute;dias&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;L&rsquo;Universit&eacute; de N&rsquo;Djamena&nbsp;;&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;Le Conseil National de Transition (CNT).&nbsp;</p>\r\n\r\n<p>Cr&eacute;ation et missions de l&rsquo;OVPCDP&nbsp;:<br />\r\nL&rsquo;Observatoire de la Violence, de la Pr&eacute;vention de la Criminalit&eacute; et de la D&eacute;ontologie Polici&egrave;re au Tchad (OVPCDP) a &eacute;t&eacute; cr&eacute;&eacute; par la loi N&deg;042/PR/2019 du 19 d&eacute;cembre 2019. L&rsquo;observatoire a pour missions de collecter, d&rsquo;analyser et de produire de l&rsquo;information en mati&egrave;re d&rsquo;incivilit&eacute;, d&rsquo;infractions, des d&eacute;lits, de crimes et de toutes formes de violence et de d&eacute;viance ainsi que la r&eacute;gulation sociale de la violence.&nbsp;<br />\r\nA ce titre l&rsquo;OVPCDP est charg&eacute; notamment de&nbsp;:&nbsp;<br />\r\n⦁&nbsp;&nbsp; &nbsp;Collecter, centraliser et actualiser toute la documentation scientifique et technique d&rsquo;origine nationale ou &eacute;trang&egrave;re dans les champs qui le concernent et pourvoir &agrave; sa diffusion dans les milieux concern&eacute;s&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;Collecter, centraliser, conserver et diss&eacute;miner les donn&eacute;es relatives &agrave; ses champs de comp&eacute;tence&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;R&eacute;aliser les &eacute;tudes et recherches scientifiques et techniques dans ses champs de comp&eacute;tence&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;Animer le milieu professionnel et scientifique en vue de favoriser les &eacute;changes ainsi que de soutenir les capacit&eacute;s de collecte et de traitement de l&rsquo;information&nbsp;;<br />\r\n⦁&nbsp;&nbsp; &nbsp;Contribuer &agrave; l&rsquo;enseignement dispens&eacute; dans les &eacute;tablissements universitaires et de formation professionnelle.&nbsp;<br />\r\nSelon les termes du d&eacute;cret N&deg;1944/PR/MSPI/2020 du 22 septembre 2020, l&rsquo;OVPCDP est compos&eacute; d&rsquo;un Comit&eacute; de Pilotage, d&rsquo;une Cellule de Gestion et d&rsquo;un Comit&eacute; Scientifique.&nbsp;</p>\r\n\r\n<p>Il est h&eacute;berg&eacute; dans les locaux de l&rsquo;Ecole Nationale d&rsquo;Administration.</p>', 'https://observatoire-td.org/observer/public/images/presentations/obs_present-465073480_1662975348.png', '2022-09-12 14:35:48', '2022-09-12 14:35:48', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `provinces`
--

CREATE TABLE `provinces` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(10) NOT NULL,
  `description` varchar(80) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `provinces`
--

INSERT INTO `provinces` (`id`, `libelle`, `description`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'BT', 'Batha', '2022-08-27 21:21:01', '2022-08-27 21:21:01', 35, NULL),
(2, 'CB', 'Chari-Baguirmi', '2022-08-27 21:21:16', '2022-08-27 21:21:16', 35, NULL),
(3, 'WF', 'Wadi Fira', '2022-08-27 21:23:04', '2022-08-27 21:23:04', 35, NULL),
(4, 'BEG', 'Bahr El Ghazel', '2022-08-27 21:23:28', '2022-08-27 21:23:28', 35, NULL),
(5, 'BK   ', 'Borkou    ', '2022-08-27 21:23:45', '2022-08-27 21:23:45', 35, NULL),
(6, 'EE', 'Ennedi Est', '2022-08-27 21:23:58', '2022-08-27 21:23:58', 35, NULL),
(7, 'EO', 'Ennedi Ouest', '2022-09-10 19:03:08', '2022-09-10 19:03:08', 35, NULL),
(8, 'GR    ', 'Guéra', '2022-08-27 21:24:55', '2022-08-27 21:24:55', 35, NULL),
(9, 'KN     ', 'Kanem', '2022-08-27 21:25:17', '2022-08-27 21:25:17', 35, NULL),
(10, 'LC       ', 'Lac', '2022-08-27 21:28:45', '2022-08-27 21:28:45', 35, NULL),
(11, 'LO', 'Logone Occidental', '2022-09-10 19:03:21', '2022-09-10 19:03:21', 35, NULL),
(12, 'LOR', 'Logone Oriental', '2022-09-10 19:03:26', '2022-09-10 19:03:26', 35, NULL),
(13, 'ML   ', 'Mandoul', '2022-08-27 21:29:49', '2022-08-27 21:29:49', 35, NULL),
(14, 'MK', 'Mayo-Kebbi', '2022-08-27 21:30:17', '2022-08-27 21:30:17', 35, NULL),
(15, 'MC', 'Moyen-Chari', '2022-09-10 19:03:38', '2022-09-10 19:03:38', 35, NULL),
(16, 'OD   ', 'Ouaddaï', '2022-08-27 21:31:46', '2022-08-27 21:31:46', 35, NULL),
(17, 'SM  ', 'Salamat', '2022-08-27 21:32:06', '2022-08-27 21:32:06', 35, NULL),
(18, 'SL      ', 'Sila', '2022-08-27 21:32:20', '2022-08-27 21:32:20', 35, NULL),
(19, 'TJ  ', 'Tandjilé', '2022-08-27 21:32:45', '2022-08-27 21:32:45', 35, NULL),
(20, 'TBT ', 'Tibesti', '2022-08-27 21:33:24', '2022-08-27 21:33:24', 35, NULL),
(21, 'NDJ', 'N\'Djamena', '2022-08-27 23:23:05', '2022-08-27 23:23:05', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `raison_satisfactions`
--

CREATE TABLE `raison_satisfactions` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(400) NOT NULL,
  `type_satisfaction` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `raison_satisfactions`
--

INSERT INTO `raison_satisfactions` (`id`, `libelle`, `type_satisfaction`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(2, 'Satisfait', 'Condamnation', '2022-09-20 17:49:05', '2022-09-20 17:49:05', 42, NULL),
(3, 'Satisfait', 'Règlement  a l\'amiable', '2022-09-20 17:50:13', '2022-09-20 17:50:13', 42, NULL),
(4, 'N/A', 'N/A', '2022-10-09 04:07:40', '2022-10-09 04:07:40', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `realisations`
--

CREATE TABLE `realisations` (
  `id` int(10) UNSIGNED NOT NULL,
  `nombre` double NOT NULL,
  `description` text NOT NULL,
  `status` varchar(50) DEFAULT 'initial',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(10) UNSIGNED NOT NULL,
  `link` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL,
  `infra_id` int(10) UNSIGNED DEFAULT NULL,
  `actus_id` int(10) UNSIGNED DEFAULT NULL,
  `enq_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `reports`
--

INSERT INTO `reports` (`id`, `link`, `created_at`, `updated_at`, `admin_id`, `super_id`, `infra_id`, `actus_id`, `enq_id`) VALUES
(1, 'https://observatoire-td.org/observer/public/images/reports/TDR_CONSULTANT_INDIVIDUEL_OU_CABINET_EN_ELABORATION_DE_DOCUMENTS_ADMINISTRATIFS_ET_FINANCIERS-703051688_1665577704.docx', '2022-10-12 17:28:24', '2022-10-12 17:28:24', 42, NULL, NULL, 46, NULL),
(2, 'https://observatoire-td.org/observer/public/images/reports/TDR_EXPERT_EN_CONCEPTION_ET_OPERATIONNALISATION_DES_OBSERVATOIRES_VF-182067342_1665650397.docx', '2022-10-13 13:39:57', '2022-10-13 13:39:57', 42, NULL, NULL, 47, NULL),
(3, 'https://observatoire-td.org/observer/public/images/reports/TDR_EXPERT_NATIONAL_EN_GESTION_DE_BASE_DE_DONNEES_VF-1661963763_1665650687.docx', '2022-10-13 13:44:47', '2022-10-13 13:44:47', 42, NULL, NULL, 48, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` int(10) UNSIGNED NOT NULL,
  `role` varchar(20) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `role`, `created_at`, `updated_at`) VALUES
(1, 'super_admin', '2022-04-02 21:25:14', NULL),
(2, 'admin', '2022-04-02 21:25:37', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rsnonenqtes`
--

CREATE TABLE `rsnonenqtes` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(400) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `rsnonenqtes`
--

INSERT INTO `rsnonenqtes` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(2, 'Honte', '2022-09-20 17:52:42', '2022-09-20 17:52:42', 42, NULL),
(3, 'N/A', '2022-10-09 04:07:12', '2022-10-09 04:07:12', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `slider01s`
--

CREATE TABLE `slider01s` (
  `id` int(10) UNSIGNED NOT NULL,
  `imgurl` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slider01s`
--

INSERT INTO `slider01s` (`id`, `imgurl`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(2, 'https://observatoire-td.org/observer/public/images/sliders/obs_05-890568019_1662944578.png', '2022-09-12 06:02:58', '2022-09-12 06:02:58', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `slider02s`
--

CREATE TABLE `slider02s` (
  `id` int(10) UNSIGNED NOT NULL,
  `imgurl` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slider02s`
--

INSERT INTO `slider02s` (`id`, `imgurl`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'https://observatoire-td.org/observer/public/images/sliders/obs_04-1642583204_1662944658.png', '2022-09-12 06:04:18', '2022-09-12 06:04:18', 35, NULL),
(2, 'https://observatoire-td.org/observer/public/images/sliders/obs_03-1716361807_1662944688.png', '2022-09-12 06:04:48', '2022-09-12 06:04:48', 35, NULL),
(3, 'https://observatoire-td.org/observer/public/images/sliders/obs_02-313694191_1662944717.png', '2022-09-12 06:05:17', '2022-09-12 06:05:17', 35, NULL),
(4, 'https://observatoire-td.org/observer/public/images/sliders/obs_01-117824649_1662945001.JPG', '2022-09-12 01:10:01', '2022-09-12 06:06:22', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `source_judiciaires`
--

CREATE TABLE `source_judiciaires` (
  `id` int(10) UNSIGNED NOT NULL,
  `fonction` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `source_judiciaires`
--

INSERT INTO `source_judiciaires` (`id`, `fonction`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(3, 'FSI', '2022-09-14 07:04:28', '2022-09-14 07:04:28', 35, NULL),
(4, 'N/A', '2022-10-09 04:08:05', '2022-10-09 04:08:05', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `source_medias`
--

CREATE TABLE `source_medias` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` text NOT NULL,
  `date` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL,
  `tmedia_id` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `source_medias`
--

INSERT INTO `source_medias` (`id`, `libelle`, `date`, `created_at`, `updated_at`, `admin_id`, `super_id`, `tmedia_id`) VALUES
(40, 'Journal en ligne', '2022-09-16', '2022-09-16 12:37:34', '2022-09-16 12:37:34', 35, NULL, 1),
(41, 'N/A', '2022-10-09', '2022-10-09 04:06:41', '2022-10-09 04:06:41', 35, NULL, 2);

-- --------------------------------------------------------

--
-- Table structure for table `superadmins`
--

CREATE TABLE `superadmins` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `user_profile` varchar(500) DEFAULT NULL,
  `password` varchar(155) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `superadmins`
--

INSERT INTO `superadmins` (`id`, `name`, `gender`, `email`, `phone`, `user_profile`, `password`, `created_at`, `updated_at`, `role_id`) VALUES
(37, 'Khalil Hisseine Hamdane', 'male', 'khalil@hltic.org', '+23566200135', 'http://localhost/lab/observer/public/images/all_profile.png', '$2y$10$eefwV6DxSTdBhIEifkJfz.xRwQzmbNVUsaToxYAalZCvhzmGbI5Uq', '2022-04-20 07:37:01', '2022-04-20 07:37:01', 1),
(39, 'Frederic Bangadinga', 'male', 'frederic@gmail.com', '+23560286069', 'http://localhost/lab/observer/public/images/all_profile.png', '$2y$10$XFukQvXzTKTQ97N.q0KP.eOjnc55mKzCDraqADnkVAwsWFDQ3ZhhK', '2022-04-20 07:39:09', '2022-04-20 07:39:09', 1);

-- --------------------------------------------------------

--
-- Table structure for table `teams`
--

CREATE TABLE `teams` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(300) NOT NULL,
  `fnction` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `teams_projects`
--

CREATE TABLE `teams_projects` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(300) NOT NULL,
  `fnction` varchar(200) NOT NULL,
  `description` text NOT NULL,
  `imgurl` varchar(500) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `teams_projects`
--

INSERT INTO `teams_projects` (`id`, `name`, `fnction`, `description`, `imgurl`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'Senoussi Hassana Abdoulaye', 'Coordonateur du projet', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-2043572538_1666088259.jpeg', '2022-10-18 15:17:39', '2022-10-18 15:17:39', 42, NULL),
(2, 'Dr. Maoundonodji Gilbert', 'Responsable technique', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-2012396397_1666088347.jpeg', '2022-10-18 15:19:07', '2022-10-18 15:19:07', 42, NULL),
(3, 'Allahissem Bruno', 'Responsable technique', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1866945493_1666088593.jpeg', '2022-10-18 15:23:13', '2022-10-18 15:23:13', 42, NULL),
(4, 'Noellie Allam-Ndoul', 'Chargée de projet', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1372264777_1666088638.jpeg', '2022-10-18 15:23:58', '2022-10-18 15:23:58', 42, NULL),
(5, 'Aziza Bichara Doudoua', 'Chargée de communication et de documentation', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1993616476_1666088671.jpeg', '2022-10-18 15:24:31', '2022-10-18 15:24:31', 42, NULL),
(6, 'Kouladoum Peurngar Pascal', 'Chargé de prospective-suivi-évaluation', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-251712183_1666088703.jpeg', '2022-10-18 15:25:03', '2022-10-18 15:25:03', 42, NULL),
(7, 'Dingambaye Abel', 'Chargé des études et des recherches', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-31549266_1666088738.jpeg', '2022-10-18 15:25:38', '2022-10-18 15:25:38', 42, NULL),
(8, 'Dr. Youssouf Doungous', 'Chargé  d\'animation des activités scientifiques', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-670737514_1666088779.jpeg', '2022-10-18 15:26:19', '2022-10-18 15:26:19', 42, NULL),
(9, 'Noubadoum Nguetebaye', 'Comptable', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1265258128_1666088811.jpeg', '2022-10-18 15:26:51', '2022-10-18 15:26:51', 42, NULL),
(10, 'Abba Tchari Abba Adji', 'Assistant comptable', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1506118877_1666088842.jpeg', '2022-10-18 15:27:22', '2022-10-18 15:27:22', 42, NULL),
(11, 'Steve Nanoudjal', 'Chargé de développement de la base des données', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1002094427_1666088877.jpeg', '2022-10-18 15:27:57', '2022-10-18 15:27:57', 42, NULL),
(12, 'Nathalie Ngaryambang', 'Assistante de coordination', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1760490747_1666088912.jpeg', '2022-10-18 15:28:32', '2022-10-18 15:28:32', 42, NULL),
(13, 'Djegom Moudjibe', 'Chauffeur', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-577757978_1666088943.jpeg', '2022-10-18 15:29:03', '2022-10-18 15:29:03', 42, NULL),
(14, 'Ndoukolnodji Mbaindigmel Mathieu', 'Chauffeur', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1216219856_1666088977.jpeg', '2022-10-18 15:29:37', '2022-10-18 15:29:37', 42, NULL),
(15, 'Ndologonodji Viviane', 'Chargée d\'entretien', 'undefined', 'https://observatoire-td.org/observer/public/images/teams/WhatsApp_Image_2022-10-17_at_9.43.45_AM-1716799022_1666089010.jpeg', '2022-10-18 15:30:10', '2022-10-18 15:30:10', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `tranche_ages`
--

CREATE TABLE `tranche_ages` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `tranche_ages`
--

INSERT INTO `tranche_ages` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(3, '18 - 25 ans', '2022-09-20 17:54:26', '2022-09-20 17:54:26', 42, NULL),
(4, '26 - 40 ans', '2022-09-20 17:55:57', '2022-09-20 17:55:57', 42, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `type_enquetes`
--

CREATE TABLE `type_enquetes` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_enquetes`
--

INSERT INTO `type_enquetes` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'Flagrance', '2022-09-20 12:46:19', '2022-09-20 12:46:19', 35, NULL),
(2, 'N/A', '2022-10-09 04:04:04', '2022-10-09 04:04:04', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `type_infractions`
--

CREATE TABLE `type_infractions` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_infractions`
--

INSERT INTO `type_infractions` (`id`, `libelle`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'Crime', '2022-09-12 18:41:12', '2022-09-12 18:41:12', 35, NULL),
(2, 'Violence', '2022-09-12 18:41:27', '2022-09-12 18:41:27', 35, NULL),
(3, 'Deontologie Policiare', '2022-09-12 18:41:41', '2022-09-12 18:41:41', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `type_medias`
--

CREATE TABLE `type_medias` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle` varchar(400) NOT NULL,
  `description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `type_medias`
--

INSERT INTO `type_medias` (`id`, `libelle`, `description`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'Journal', 'Journal en ligne', '2022-09-16 12:20:57', '2022-09-16 12:20:57', 35, NULL),
(2, 'N/A', 'N/A', '2022-10-09 04:05:45', '2022-10-09 04:05:45', 35, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `type_professions`
--

CREATE TABLE `type_professions` (
  `id` int(10) UNSIGNED NOT NULL,
  `libelle_type_pr` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(25) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(25) NOT NULL,
  `user_profile` varchar(500) DEFAULT NULL,
  `password` varchar(155) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `role_id` int(10) UNSIGNED NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `victimes`
--

CREATE TABLE `victimes` (
  `id` int(10) UNSIGNED NOT NULL,
  `nom` varchar(255) NOT NULL,
  `prenom` varchar(25) NOT NULL,
  `profile` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `admin_id` int(10) UNSIGNED DEFAULT NULL,
  `super_id` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `victimes`
--

INSERT INTO `victimes` (`id`, `nom`, `prenom`, `profile`, `created_at`, `updated_at`, `admin_id`, `super_id`) VALUES
(1, 'N/A', 'N/A', NULL, '2022-10-08 15:57:40', '2022-10-08 15:57:40', 35, NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activites`
--
ALTER TABLE `activites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `actualites`
--
ALTER TABLE `actualites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `tbl_roles_01` (`role_id`),
  ADD KEY `id` (`id`,`role_id`),
  ADD KEY `tbl_super_05` (`super_id`);

--
-- Indexes for table `autoritesaisies`
--
ALTER TABLE `autoritesaisies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `categorieprofessionels`
--
ALTER TABLE `categorieprofessionels`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `decision_finals`
--
ALTER TABLE `decision_finals`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `enquetes`
--
ALTER TABLE `enquetes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_decisions`
--
ALTER TABLE `etat_decisions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_denonciations`
--
ALTER TABLE `etat_denonciations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_enqtes`
--
ALTER TABLE `etat_enqtes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_gardeavues`
--
ALTER TABLE `etat_gardeavues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_infra_jours`
--
ALTER TABLE `etat_infra_jours`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`),
  ADD KEY `tbl_etat_infra` (`id_infra`),
  ADD KEY `tbl_etat_tinfra` (`id_tinfra`),
  ADD KEY `tbl_etat_victime` (`id_victime`),
  ADD KEY `tbl_etat_age` (`id_age`),
  ADD KEY `tbl_provice_age` (`id_province`),
  ADD KEY `tbl_etat_lieu` (`id_lieu_infra`),
  ADD KEY `tbl_autho` (`id_autho`),
  ADD KEY `tbl_decision` (`id_decision`),
  ADD KEY `tbl_etat_gravue` (`id_gravue`),
  ADD KEY `tbl_neqte` (`id_neqte`),
  ADD KEY `tbl_etat_satisfact` (`id_satisfact`),
  ADD KEY `tbl_etat_judiciare` (`id_judiciaire`),
  ADD KEY `tbl_etat_osc` (`id_osc`),
  ADD KEY `tbl_etat_media` (`id_media`),
  ADD KEY `tbl_etat_enqt` (`id_enqt`);

--
-- Indexes for table `etat_judiciaires`
--
ALTER TABLE `etat_judiciaires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_media_sources`
--
ALTER TABLE `etat_media_sources`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_non_enqtes`
--
ALTER TABLE `etat_non_enqtes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_oscs`
--
ALTER TABLE `etat_oscs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `etat_satisfactions`
--
ALTER TABLE `etat_satisfactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `fsis`
--
ALTER TABLE `fsis`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `galleries`
--
ALTER TABLE `galleries`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `gerdeavues`
--
ALTER TABLE `gerdeavues`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `infractions`
--
ALTER TABLE `infractions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`),
  ADD KEY `tbl_type_01` (`type_id`);

--
-- Indexes for table `infras_imports`
--
ALTER TABLE `infras_imports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lieu_infras`
--
ALTER TABLE `lieu_infras`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`),
  ADD KEY `infra_id` (`infra_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `oscs`
--
ALTER TABLE `oscs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `partenaires`
--
ALTER TABLE `partenaires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `partener02s`
--
ALTER TABLE `partener02s`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `presentations`
--
ALTER TABLE `presentations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `provinces`
--
ALTER TABLE `provinces`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `raison_satisfactions`
--
ALTER TABLE `raison_satisfactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `realisations`
--
ALTER TABLE `realisations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`),
  ADD KEY `infra_id` (`infra_id`),
  ADD KEY `tbl_actus_01` (`actus_id`),
  ADD KEY `tbl_enq_01` (`enq_id`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rsnonenqtes`
--
ALTER TABLE `rsnonenqtes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `slider01s`
--
ALTER TABLE `slider01s`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `slider02s`
--
ALTER TABLE `slider02s`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `source_judiciaires`
--
ALTER TABLE `source_judiciaires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `source_medias`
--
ALTER TABLE `source_medias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`),
  ADD KEY `tmedia_id` (`tmedia_id`);

--
-- Indexes for table `superadmins`
--
ALTER TABLE `superadmins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `tbl_roles` (`role_id`),
  ADD KEY `id` (`id`,`role_id`);

--
-- Indexes for table `teams`
--
ALTER TABLE `teams`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `teams_projects`
--
ALTER TABLE `teams_projects`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `tranche_ages`
--
ALTER TABLE `tranche_ages`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `type_enquetes`
--
ALTER TABLE `type_enquetes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `type_infractions`
--
ALTER TABLE `type_infractions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `type_medias`
--
ALTER TABLE `type_medias`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `type_professions`
--
ALTER TABLE `type_professions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`),
  ADD KEY `tbl_roles_03` (`role_id`),
  ADD KEY `id` (`id`,`role_id`);

--
-- Indexes for table `victimes`
--
ALTER TABLE `victimes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`),
  ADD KEY `super_id` (`super_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activites`
--
ALTER TABLE `activites`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `actualites`
--
ALTER TABLE `actualites`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;

--
-- AUTO_INCREMENT for table `autoritesaisies`
--
ALTER TABLE `autoritesaisies`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `categorieprofessionels`
--
ALTER TABLE `categorieprofessionels`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `decision_finals`
--
ALTER TABLE `decision_finals`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enquetes`
--
ALTER TABLE `enquetes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `etat_decisions`
--
ALTER TABLE `etat_decisions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `etat_denonciations`
--
ALTER TABLE `etat_denonciations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `etat_enqtes`
--
ALTER TABLE `etat_enqtes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `etat_gardeavues`
--
ALTER TABLE `etat_gardeavues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `etat_infra_jours`
--
ALTER TABLE `etat_infra_jours`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `etat_judiciaires`
--
ALTER TABLE `etat_judiciaires`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `etat_media_sources`
--
ALTER TABLE `etat_media_sources`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `etat_non_enqtes`
--
ALTER TABLE `etat_non_enqtes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `etat_oscs`
--
ALTER TABLE `etat_oscs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `etat_satisfactions`
--
ALTER TABLE `etat_satisfactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fsis`
--
ALTER TABLE `fsis`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `galleries`
--
ALTER TABLE `galleries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `gerdeavues`
--
ALTER TABLE `gerdeavues`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `infractions`
--
ALTER TABLE `infractions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `infras_imports`
--
ALTER TABLE `infras_imports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `lieu_infras`
--
ALTER TABLE `lieu_infras`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `oscs`
--
ALTER TABLE `oscs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `partenaires`
--
ALTER TABLE `partenaires`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `partener02s`
--
ALTER TABLE `partener02s`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `presentations`
--
ALTER TABLE `presentations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `provinces`
--
ALTER TABLE `provinces`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `raison_satisfactions`
--
ALTER TABLE `raison_satisfactions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `realisations`
--
ALTER TABLE `realisations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `rsnonenqtes`
--
ALTER TABLE `rsnonenqtes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `slider01s`
--
ALTER TABLE `slider01s`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `slider02s`
--
ALTER TABLE `slider02s`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `source_judiciaires`
--
ALTER TABLE `source_judiciaires`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `source_medias`
--
ALTER TABLE `source_medias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `superadmins`
--
ALTER TABLE `superadmins`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `teams`
--
ALTER TABLE `teams`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `teams_projects`
--
ALTER TABLE `teams_projects`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `tranche_ages`
--
ALTER TABLE `tranche_ages`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `type_enquetes`
--
ALTER TABLE `type_enquetes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type_infractions`
--
ALTER TABLE `type_infractions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `type_medias`
--
ALTER TABLE `type_medias`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `type_professions`
--
ALTER TABLE `type_professions`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `victimes`
--
ALTER TABLE `victimes`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activites`
--
ALTER TABLE `activites`
  ADD CONSTRAINT `tbl_admin_33` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_33` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `actualites`
--
ALTER TABLE `actualites`
  ADD CONSTRAINT `tbl_admin_30` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_30` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `admins`
--
ALTER TABLE `admins`
  ADD CONSTRAINT `tbl_roles_01` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `autoritesaisies`
--
ALTER TABLE `autoritesaisies`
  ADD CONSTRAINT `tbl_admin_20` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_20` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `categorieprofessionels`
--
ALTER TABLE `categorieprofessionels`
  ADD CONSTRAINT `tbl_admin_27` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_27` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `decision_finals`
--
ALTER TABLE `decision_finals`
  ADD CONSTRAINT `tbl_admin_22` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_22` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `enquetes`
--
ALTER TABLE `enquetes`
  ADD CONSTRAINT `tbl_admin_31` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_31` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `etat_decisions`
--
ALTER TABLE `etat_decisions`
  ADD CONSTRAINT `tbl_admin_29` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_29` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_denonciations`
--
ALTER TABLE `etat_denonciations`
  ADD CONSTRAINT `tbl_admin_21` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_21` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_enqtes`
--
ALTER TABLE `etat_enqtes`
  ADD CONSTRAINT `tbl_admin_34` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_34` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_gardeavues`
--
ALTER TABLE `etat_gardeavues`
  ADD CONSTRAINT `tbl_admin_35` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_35` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_infra_jours`
--
ALTER TABLE `etat_infra_jours`
  ADD CONSTRAINT `tbl_admin_18` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_autho` FOREIGN KEY (`id_autho`) REFERENCES `autoritesaisies` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_decision` FOREIGN KEY (`id_decision`) REFERENCES `decision_finals` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_age` FOREIGN KEY (`id_age`) REFERENCES `tranche_ages` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_enqt` FOREIGN KEY (`id_enqt`) REFERENCES `type_enquetes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_gravue` FOREIGN KEY (`id_gravue`) REFERENCES `gerdeavues` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_infra` FOREIGN KEY (`id_infra`) REFERENCES `infractions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_judiciare` FOREIGN KEY (`id_judiciaire`) REFERENCES `source_judiciaires` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_lieu` FOREIGN KEY (`id_lieu_infra`) REFERENCES `lieu_infras` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_media` FOREIGN KEY (`id_media`) REFERENCES `source_medias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_osc` FOREIGN KEY (`id_osc`) REFERENCES `oscs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_satisfact` FOREIGN KEY (`id_satisfact`) REFERENCES `raison_satisfactions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_tinfra` FOREIGN KEY (`id_tinfra`) REFERENCES `type_infractions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_etat_victime` FOREIGN KEY (`id_victime`) REFERENCES `victimes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_neqte` FOREIGN KEY (`id_neqte`) REFERENCES `rsnonenqtes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_provice_age` FOREIGN KEY (`id_province`) REFERENCES `provinces` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_18` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `etat_judiciaires`
--
ALTER TABLE `etat_judiciaires`
  ADD CONSTRAINT `tbl_admin_41` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_41` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_media_sources`
--
ALTER TABLE `etat_media_sources`
  ADD CONSTRAINT `tbl_admin_39` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_39` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_non_enqtes`
--
ALTER TABLE `etat_non_enqtes`
  ADD CONSTRAINT `tbl_admin_37` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_37` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_oscs`
--
ALTER TABLE `etat_oscs`
  ADD CONSTRAINT `tbl_admin_42` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_42` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `etat_satisfactions`
--
ALTER TABLE `etat_satisfactions`
  ADD CONSTRAINT `tbl_admin_40` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_40` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);

--
-- Constraints for table `fsis`
--
ALTER TABLE `fsis`
  ADD CONSTRAINT `tbl_admin_03` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_03` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `galleries`
--
ALTER TABLE `galleries`
  ADD CONSTRAINT `tbl_admin_16` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_16` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `gerdeavues`
--
ALTER TABLE `gerdeavues`
  ADD CONSTRAINT `tbl_admin_23` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_23` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `infractions`
--
ALTER TABLE `infractions`
  ADD CONSTRAINT `tbl_admin_01` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_01` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_type_01` FOREIGN KEY (`type_id`) REFERENCES `type_infractions` (`id`);

--
-- Constraints for table `lieu_infras`
--
ALTER TABLE `lieu_infras`
  ADD CONSTRAINT `tbl_admin_07` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_infra_03` FOREIGN KEY (`infra_id`) REFERENCES `infractions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_07` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `oscs`
--
ALTER TABLE `oscs`
  ADD CONSTRAINT `tbl_admin_06` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_06` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partenaires`
--
ALTER TABLE `partenaires`
  ADD CONSTRAINT `tbl_admin_038` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_038` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `partener02s`
--
ALTER TABLE `partener02s`
  ADD CONSTRAINT `tbl_admin_039` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_039` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `presentations`
--
ALTER TABLE `presentations`
  ADD CONSTRAINT `tbl_admin_32` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_32` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `provinces`
--
ALTER TABLE `provinces`
  ADD CONSTRAINT `tbl_admin_26` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_26` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `raison_satisfactions`
--
ALTER TABLE `raison_satisfactions`
  ADD CONSTRAINT `tbl_admin_38` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_38` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `realisations`
--
ALTER TABLE `realisations`
  ADD CONSTRAINT `tbl_admin_36` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_36` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `tbl_actus_01` FOREIGN KEY (`actus_id`) REFERENCES `actualites` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_admin_016` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_enq_01` FOREIGN KEY (`enq_id`) REFERENCES `enquetes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_infra_02` FOREIGN KEY (`infra_id`) REFERENCES `infractions` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_016` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rsnonenqtes`
--
ALTER TABLE `rsnonenqtes`
  ADD CONSTRAINT `tbl_admin_24` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_24` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `slider01s`
--
ALTER TABLE `slider01s`
  ADD CONSTRAINT `tbl_admin_11` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tbl_super_11` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `slider02s`
--
ALTER TABLE `slider02s`
  ADD CONSTRAINT `tbl_admin_10` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `tbl_super_10` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `source_judiciaires`
--
ALTER TABLE `source_judiciaires`
  ADD CONSTRAINT `tbl_admin_02` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_02` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `source_medias`
--
ALTER TABLE `source_medias`
  ADD CONSTRAINT `tbl_admin_017` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_media_02` FOREIGN KEY (`tmedia_id`) REFERENCES `type_medias` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_017` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `superadmins`
--
ALTER TABLE `superadmins`
  ADD CONSTRAINT `tbl_roles` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams`
--
ALTER TABLE `teams`
  ADD CONSTRAINT `tbl_admin_018` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_018` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `teams_projects`
--
ALTER TABLE `teams_projects`
  ADD CONSTRAINT `tbl_admin_019` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_019` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `tranche_ages`
--
ALTER TABLE `tranche_ages`
  ADD CONSTRAINT `tbl_admin_45` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_45` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `type_enquetes`
--
ALTER TABLE `type_enquetes`
  ADD CONSTRAINT `tbl_admin_25` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_25` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `type_infractions`
--
ALTER TABLE `type_infractions`
  ADD CONSTRAINT `tbl_admin_015` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_015` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `type_medias`
--
ALTER TABLE `type_medias`
  ADD CONSTRAINT `tbl_admin_04` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_04` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `type_professions`
--
ALTER TABLE `type_professions`
  ADD CONSTRAINT `tbl_admin_28` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `tbl_super_28` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `tbl_roles_03` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `victimes`
--
ALTER TABLE `victimes`
  ADD CONSTRAINT `tbl_admin_19` FOREIGN KEY (`admin_id`) REFERENCES `admins` (`id`),
  ADD CONSTRAINT `tbl_super_19` FOREIGN KEY (`super_id`) REFERENCES `superadmins` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
