<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\SourceController;
use App\Http\Controllers\InfractionController;

Route::get('/', [InfractionController::class, 'index']);
Route::post('upload-data', [InfractionController::class, 'importFile']);
Route::get('export', [InfractionController::class, 'exportFile']);

Route::get('enquetes', [InfractionController::class, 'enquetes']);
Route::post('enquetes-import', [InfractionController::class, 'importEnqueteFile']);
Route::get('enquetes-export', [InfractionController::class, 'exportEnqueteFile']);


Route::get('type-infra', [InfractionController::class, 'typeInfra']);
Route::post('typeinfra-import', [InfractionController::class, 'importTypeInfraFile']);
Route::get('typeinfra-export', [InfractionController::class, 'exportTypeInfraFile']);


Route::get('lieu-infras', [InfractionController::class, 'lieuInfras']);
Route::post('lieuInfras-import', [InfractionController::class, 'importLieuInfraFile']);
Route::get('lieuinfras-export', [InfractionController::class, 'lieuInfrasInfraFile']);

Route::get('victimes', [InfractionController::class, 'victimes']);
Route::post('victimes-import', [InfractionController::class, 'importVictimesFile']);
Route::get('victimes-export', [InfractionController::class, 'victimeFile']);

Route::get('etatInfras', [InfractionController::class, 'etatInfras']);
Route::post('etatInfras-import', [InfractionController::class, 'importetatInfrasFile']);
Route::post('etatInfras-export', [InfractionController::class, 'etatInfrasFile']);

Route::get('source-judiciaires', [SourceController::class, 'sourceJudiciaires']);
Route::post('sourcejudiciaires-import', [SourceController::class, 'importsourceJudiciaire']);
Route::get('sourcejudiciaires-export', [SourceController::class, 'sourceJudiciaireFile']);

Route::get('type-medias', [SourceController::class, 'typeMedias']);
Route::post('typemedia-import', [SourceController::class, 'importTypeMedias']);
Route::get('typemedia-export', [SourceController::class, 'typeMediaFile']);

Route::get('source-medias', [SourceController::class, 'sourceMedias']);
Route::post('sourcemedia-import', [SourceController::class, 'importSourceMedias']);
Route::get('sourcemedia-export', [SourceController::class, 'sourceMediaFile']);

Route::get('osc-source', [SourceController::class, 'sourceOSC']);
Route::post('osc-import', [SourceController::class, 'importOSC']);
Route::get('osc-export', [SourceController::class, 'OSCFile']);

Route::get('fsi-source', [SourceController::class, 'sourceFSI']);
Route::post('fsi-import', [SourceController::class, 'importFSI']);
Route::get('fsi-export', [SourceController::class, 'FSIFile']);

Route::get('catpros', [SourceController::class, 'catPros']);
Route::post('catpro-import', [SourceController::class, 'importCatPro']);
Route::get('catpro-export', [SourceController::class, 'catProFile']);

Route::get('provinces', [SourceController::class, 'provinces']);
Route::post('provinces-import', [SourceController::class, 'importProvince']);
Route::get('provinces-export', [SourceController::class, 'provinceFile']);

Route::get('crimes', [InfractionController::class, 'etatInfrasCrime']);
Route::get('crime-export', [InfractionController::class, 'crimeInfrasFile']);
Route::get('violences', [InfractionController::class, 'etatInfrasViolence']);
Route::get('violence-export', [InfractionController::class, 'violenceInfrasFile']);
Route::get('deontologies', [InfractionController::class, 'etatInfrasDeontologie']);
Route::get('deontologie-export', [InfractionController::class, 'deontologieInfrasFile']);

Route::get('infractions', [InfractionController::class, 'infractions']);
Route::post('infractions-import', [InfractionController::class, 'importInfractionsFile']);
Route::get('infractions-export', [InfractionController::class, 'infractionsFile']);
