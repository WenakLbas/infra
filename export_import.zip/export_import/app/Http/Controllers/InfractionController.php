<?php

namespace App\Http\Controllers;




use DB;
use File;
use Excel;
use App\Models\Enquete;
use App\Models\Victime;
use App\Models\EtatInfra;
use App\Models\Infraction;
use Illuminate\Http\Request;
use App\Exports\VictimeExport;
use App\Exports\EnqueteeExport;
use App\Exports\EtatInfraExport;
use App\Exports\InfractionExport;
use App\Exports\TypeTnfractionExport;
use App\Exports\LieuInfractionExport;
use App\Imports\VictimeImport;
use App\Imports\EnqueteImport;
use App\Imports\InfractionImport;
use App\Imports\TypeTnfractionImport;
use App\Imports\LieuInfractionImport;
use App\Imports\InfractionsImport;
use App\Models\TypeTnfraction;
use App\Exports\CrimeExport;
use App\Exports\DeontologieExport;
use App\Exports\ViolenceExport;
use App\Models\LieuInfraction;
use App\Models\Infractions;

class InfractionController extends Controller
{
    public function index(){
        $employees =  DB::table('infractions')
            ->join('type_infractions', 'type_infractions.id', '=', 'infractions.type_id')
            ->select('infractions.*', 'type_infractions.id as tinfra_id', 'type_infractions.libelle as t_infra_lib')
            ->get();
        return view('excel-read', ['emps' => $employees]);
    }

    public function importFile(Request $request){

        if($request->hasFile('excelFile'))
        {
            $extension = File::extension($request->excelFile->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('excelFile')->getRealPath();
                Excel::import(new InfractionImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function exportFile(){
        return Excel::download(new InfractionExport(), 'infractions.xlsx');
    }

    public function infractions(){
        $infractions = Infractions::get();
        return view('infractions', ['infractions' => $infractions]);
    }

    public function importInfractionsFile(Request $request){

        //dd($request->infractionsFile);

        if($request->hasFile('infractionsFile'))
        {

            // dd($request->infractionsFile);

            $extension = File::extension($request->infractionsFile->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('infractionsFile')->getRealPath();
                Excel::import(new InfractionsImport, $path);
                Return '<h1 style="color: green">Données importées avec succes...!</h1>';
            }else {
                $request->validate([
                    'infractions' => 'required|mimes:xls, xlsx, csv'
                ]);
            }


        }
    }

    public function infractionsFile(){
        return Excel::download(new VictimeExport(), 'infractions.xlsx');
    }

    public function enquetes(){
        $enquetes = Enquete::get();
        return view('enquetes', ['enquetes' => $enquetes]);
    }

    public function importEnqueteFile(Request $request){

        if($request->hasFile('enquteFile'))
        {
            $extension = File::extension($request->enquteFile->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('enquteFile')->getRealPath();
                Excel::import(new EnqueteImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'enquteFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function exportEnqueteFile(){
        return Excel::download(new EnqueteeExport(), 'enquetes.xlsx');
    }

    public function typeInfra(){
        $typeInfras = TypeTnfraction::get();
        return view('type-infras', ['typeInfras' => $typeInfras]);
    }

    public function importTypeInfraFile(Request $request){

        if($request->hasFile('typeInfraFile'))
        {
            $extension = File::extension($request->typeInfraFile->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('typeInfraFile')->getRealPath();
                Excel::import(new TypeTnfractionImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'typeInfraFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function exportTypeInfraFile(){
        return Excel::download(new TypeTnfractionExport(), 'typeInfras.xlsx');
    }

    public function lieuInfras(){
        $lieuInfras = LieuInfraction::get();
        return view('lieu-infras', ['lieuInfras' => $lieuInfras]);
    }

    public function importLieuInfraFile(Request $request){

        if($request->hasFile('lieuInfra'))
        {
            $extension = File::extension($request->lieuInfra->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('lieuInfra')->getRealPath();
                Excel::import(new LieuInfractionImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'lieuInfra' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function lieuInfrasInfraFile(){
        return Excel::download(new LieuInfractionExport(), 'lieuInfras.xlsx');
    }

    public function victimes(){
        $victimes = Victime::get();
        return view('victimes', ['victimes' => $victimes]);
    }

    public function importVictimesFile(Request $request){

        if($request->hasFile('victime'))
        {
            $extension = File::extension($request->victime->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('victime')->getRealPath();
                Excel::import(new VictimeImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'victime' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function victimeFile(){
        return Excel::download(new VictimeExport(), 'victimes.xlsx');
    }



    public function etatInfras(){

        /*
        $etatinfras  = EtatInfra::orderBy('date_infra', 'desc')
            ->leftjoin('provinces', 'etat_infra_jours.id_province',  '=', 'provinces.id')
            ->leftjoin('infractions', 'etat_infra_jours.id_infra',  '=', 'infractions.id')
            ->leftjoin('type_infractions', 'etat_infra_jours.id_tinfra',  '=', 'type_infractions.id')
            ->select('etat_infra_jours.*', 'provinces.description as descript', 'infractions.libelle_inf', 'type_infractions.libelle as type_infras')
            ->get();
          */
        $infractions  = Infractions::orderBy('date', 'desc')
            ->select('infras_imports.*')
            ->get();

        return view('etatinfras', ['infractions' => $infractions]);
    }

     public function etatInfrasCrime(){

           /* $etatinfras  = EtatInfra::orderBy('date_infra', 'desc')
                ->leftjoin('provinces', 'etat_infra_jours.id_province',  '=', 'provinces.id')
                ->leftjoin('infractions', 'etat_infra_jours.id_infra',  '=', 'infractions.id')
                ->leftjoin('type_infractions', 'etat_infra_jours.id_tinfra',  '=', 'type_infractions.id')
                ->select('etat_infra_jours.*', 'provinces.description', 'infractions.libelle_inf', 'type_infractions.libelle')
                ->where(['type_infractions.libelle' => 'Crime'])
                ->get();*/

         $infractions  = Infractions::orderBy('date', 'desc')
                ->select('infras_imports.*')
                ->where(['type_infraction' => 'crime'])
                ->get();

            return view('crime', ['infractions' => $infractions]);
    }

     public function etatInfrasViolence(){

            /*
            $etatinfras  = EtatInfra::orderBy('date_infra', 'desc')
                ->leftjoin('provinces', 'etat_infra_jours.id_province',  '=', 'provinces.id')
                ->leftjoin('infractions', 'etat_infra_jours.id_infra',  '=', 'infractions.id')
                ->leftjoin('type_infractions', 'etat_infra_jours.id_tinfra',  '=', 'type_infractions.id')
                ->select('etat_infra_jours.*', 'provinces.description', 'infractions.libelle_inf', 'type_infractions.libelle')
                ->where(['type_infractions.libelle' => 'Violence'])
                ->get();
            */
         $infractions  = Infractions::orderBy('date', 'desc')
             ->select('infras_imports.*')
             ->where(['type_infraction' => 'violence'])
             ->get();

            return view('violence', ['infractions' => $infractions]);
    }

     public function etatInfrasDeontologie(){
            /*
            $etatinfras  = EtatInfra::orderBy('date_infra', 'desc')
                ->leftjoin('provinces', 'etat_infra_jours.id_province',  '=', 'provinces.id')
                ->leftjoin('infractions', 'etat_infra_jours.id_infra',  '=', 'infractions.id')
                ->leftjoin('type_infractions', 'etat_infra_jours.id_tinfra',  '=', 'type_infractions.id')
                ->select('etat_infra_jours.*', 'provinces.description', 'infractions.libelle_inf', 'type_infractions.libelle')
                ->where(['type_infractions.libelle' => 'Deontologie Policiare'])
                ->get();
            */

         $infractions  = Infractions::orderBy('date', 'desc')
             ->select('infras_imports.*')
             ->where(['type_infraction' => 'deontologie policiare'])
             ->get();

         return view('deontologie', ['infractions' => $infractions]);
    }

    public function importetatInfrasFile(Request $request){

        if($request->hasFile('etatinfra'))
        {
            $extension = File::extension($request->victime->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('etatinfra')->getRealPath();
                Excel::import(new EtatInfraImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'victime' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function etatInfrasFile(Request $req){
        // dd($req->datefrom, $req->dateto);
        return Excel::download(new EtatInfraExport($req->datefrom, $req->dateto), 'etat_infra.xlsx');
    }

    public function crimeInfrasFile(){
        return Excel::download(new CrimeExport(), 'etat_infra-cime.xlsx');
    }
    public function violenceInfrasFile(){
        return Excel::download(new ViolenceExport(), 'etat_infra-violence.xlsx');
    }
    public function deontologieInfrasFile(){
        return Excel::download(new DeontologieExport(), 'etat_infra-deontologie.xlsx');
    }






}
