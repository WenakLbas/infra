<?php

namespace App\Http\Controllers;

use File;
use Excel;
use App\Models\FSI;
use App\Models\OSC;
use App\Models\Province;
use App\Imports\FSImport;
use App\Models\TypeMedias;
use App\Imports\OSCImport;
use App\Exports\OSCExport;
use App\Exports\FSIExport;
use Illuminate\Http\Request;
use App\Models\SourceMedias;
use App\Exports\CatProExport;
use App\Imports\CatProImport;
use App\Exports\ProvinceExport;
use App\Imports\ProvinceImport;
use App\Models\SourceJudiciaire;
use App\Imports\TypeMediasImport;
use App\Exports\TypeMediasExport;
use App\Exports\SourceMediasExport;
use App\Imports\SourceMediasImport;
use App\Models\CategorieProfessionel;
use App\Exports\SourceJudiciaireExport;
use App\Imports\SourceJudiciaireImport;


class SourceController extends Controller
{

    public function sourceJudiciaires(){
        $sourceJudiciaires = SourceJudiciaire::get();
        return view('source-judiciaires', ['sourceJudiciaires' => $sourceJudiciaires]);
    }

    public function importsourceJudiciaire(Request $request){

        if($request->hasFile('sourceJudiciaire'))
        {
            $extension = File::extension($request->sourceJudiciaire->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('sourceJudiciaire')->getRealPath();
                Excel::import(new SourceJudiciaireImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function sourceJudiciaireFile(){
        return Excel::download(new SourceJudiciaireExport(), 'sourceJudiciaire.xlsx');
    }

    public function typeMedias(){
        $typeMedias = TypeMedias::get();
        return view('type-medias', ['typeMedias' => $typeMedias]);
    }

    public function importTypeMedias(Request $request){

        if($request->hasFile('typeMedia'))
        {
            $extension = File::extension($request->typeMedia->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('typeMedia')->getRealPath();
                Excel::import(new TypeMediasImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function typeMediaFile(){
        return Excel::download(new TypeMediasExport(), 'typeMedia.xlsx');
    }



    public function sourceMedias(){
        $sourceMedias = SourceMedias::get();
        return view('source-medias', ['sourceMedias' => $sourceMedias]);
    }

    public function importSourceMedias(Request $request){

        if($request->hasFile('sourceMedia'))
        {
            $extension = File::extension($request->sourceMedia->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('sourceMedia')->getRealPath();
                Excel::import(new SourceMediasImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function sourceMediaFile(){
        return Excel::download(new SourceMediasExport(), 'sourceMedia.xlsx');
    }

    public function sourceOSC(){
        $oscs = OSC::get();
        return view('oscs', ['oscs' => $oscs]);
    }

    public function importOSC(Request $request){

        if($request->hasFile('osc'))
        {
            $extension = File::extension($request->osc->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('osc')->getRealPath();
                Excel::import(new OSCImport, $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function OSCFile(){
        return Excel::download(new OSCExport(), 'osc.xlsx');
    }

    public function sourceFSI(){
        $fsis = FSI::get();
        return view('fsis', ['fsis' => $fsis]);
    }

    public function importFSI(Request $request){

        if($request->hasFile('fsi'))
        {
            $extension = File::extension($request->fsi->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('fsi')->getRealPath();
                Excel::import(new FSImport(), $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function FSIFile(){
        return Excel::download(new FSIExport(), 'fsi.xlsx');
    }


    public function catPros(){
        $catpros = CategorieProfessionel::get();
        return view('catpro', ['catpros' => $catpros]);
    }

    public function importCatPro(Request $request){

        if($request->hasFile('catpro'))
        {
            $extension = File::extension($request->catpro->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('catpro')->getRealPath();
                Excel::import(new CatProImport(), $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function catProFile(){
        return Excel::download(new CatProExport(), 'CatPro.xlsx');
    }

    public function provinces(){
        $provinces = Province::get();
        return view('provinces', ['provinces' => $provinces]);
    }

    public function importProvince(Request $request){

        if($request->hasFile('province'))
        {
            $extension = File::extension($request->province->getClientOriginalName());
            if ($extension == "xlsx" || $extension == "xls" || $extension == "csv") {
                $path = $request->file('province')->getRealPath();
                Excel::import(new ProvinceImport(), $path);
                Return 'Data has been imported successfuly...!';
            }else {
                $request->validate([
                    'excelFile' => 'required|mimes:xls, xlsx, csv'
                ]);
            }
        }
    }

    public function provinceFile(){
        return Excel::download(new ProvinceExport(), 'provinces.xlsx');
    }

}
