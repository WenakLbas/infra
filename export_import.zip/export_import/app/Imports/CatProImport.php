<?php

namespace App\Imports;

use App\Models\CategorieProfessionel;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class CatProImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new CategorieProfessionel([
            'admin_id' => $row['admin_id'],
            'libelle_cat' => $row['libelle_cat'],
        ]);
    }
}
