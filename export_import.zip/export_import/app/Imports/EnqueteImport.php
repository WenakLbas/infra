<?php

namespace App\Imports;

use App\Models\Enquete;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class EnqueteImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Enquete([
            'admin_id' => $row['admin_id'],
            'titre' => $row['titre'],
            'slag' => $row['slag'],
            'description' => $row['description'],
        ]);
    }
}
