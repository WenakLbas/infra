<?php

namespace App\Imports;

use App\Models\TypeTnfraction;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class TypeTnfractionImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new TypeTnfraction([
            'admin_id' => $row['admin_id'],
            'libelle' => $row['libelle'],
        ]);
    }
}
