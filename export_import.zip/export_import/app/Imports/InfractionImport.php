<?php

namespace App\Imports;

use App\Models\Infraction;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class InfractionImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new Infraction([
            'libelle_inf' => $row['libelle_inf'],
            'admin_id' => $row['admin_id'],
            'type_id' => $row['type_id'],
        ]);
    }
}
