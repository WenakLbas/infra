<?php

namespace App\Imports;

use App\Models\FSI;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class FSImport implements ToModel, WithHeadingRow
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new FSI([
            'struct_securitaire' => $row['struct_securitaire'],
            'type_post' => $row['type_post'],
            'fonction_fsi' => $row['fonction_fsi'],
            'admin_id' => $row['admin_id'],
        ]);
    }
}
