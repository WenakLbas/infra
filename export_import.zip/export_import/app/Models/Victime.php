<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Victime extends Model
{
    use HasFactory;
    protected $table = 'victimes';

    protected $fillable = ['admin_id', 'nom', 'prenom', 'profile'];

    public static function getTypeTnfraction(){
        $record = DB::table('victimes')->select('admin_id', 'nom', 'prenom', 'profile');
        return $record;
    }
}
