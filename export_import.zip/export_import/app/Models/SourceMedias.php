<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SourceMedias extends Model
{
    use HasFactory;
    protected $table = 'source_medias';

    protected $fillable = ['admin_id', 'super_id', 'libelle', 'date', 'tmedia_id'];

    public static function getSourceMedias(){
        $record = DB::table('type_medias')->select('admin_id', 'super_id', 'libelle', 'date', 'tmedia_id');
        return $record;
    }
}
