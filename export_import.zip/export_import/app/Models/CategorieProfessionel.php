<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class CategorieProfessionel extends Model
{
    use HasFactory;

    protected $table = 'categorieprofessionels';

    protected $fillable = ['admin_id', 'super_id', 'libelle_cat'];

    public static function getCatPro(){
        $record = DB::table('categorieprofessionels')->select('admin_id', 'super_id', 'libelle_cat');
        return $record;
    }
}
