<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeMedias extends Model
{
    use HasFactory;
    protected $table = 'type_medias';

    protected $fillable = ['admin_id', 'super_id', 'libelle', 'description'];

    public static function getTypeMedias(){
        $record = DB::table('type_medias')->select('admin_id', 'super_id', 'libelle', 'description');
        return $record;
    }
}
