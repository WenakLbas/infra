<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class LieuInfraction extends Model
{
    use HasFactory;

    protected $table = 'lieu_infras';

    protected $fillable = ['admin_id', 'super_id', 'libelle'];

    public static function getTypeTnfraction(){
        $record = DB::table('lieu_infras')->select('admin_id', 'super_id', 'libelle');
        return $record;
    }
}
