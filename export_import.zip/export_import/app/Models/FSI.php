<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class FSI extends Model
{
    use HasFactory;
    protected $table = 'fsis';

    protected $fillable = ['admin_id', 'super_id', 'struct_securitaire', 'type_post', 'fonction_fsi'];

    public static function getInfraction(){
        $record = DB::table('infractions')->select('admin_id', 'super_id', 'struct_securitaire', 'type_post', 'fonction_fsi');
        return $record;
    }
}
