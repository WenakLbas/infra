<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SourceJudiciaire extends Model
{
    use HasFactory;
    protected $table = 'source_judiciaires';
    protected $fillable = ['admin_id', 'super_id', 'fonction'];

    public static function getTypeSourceJudiciaire(){
        $record = DB::table('source_judiciaires')->select('admin_id', 'super_id', 'fonction');
        return $record;
    }
}
