<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class TypeTnfraction extends Model
{
    protected $table = 'type_infractions';

    protected $fillable = ['admin_id', 'super_id', 'libelle'];

    public static function getTypeTnfraction(){
        $record = DB::table('type_infractions')->select('admin_id', 'super_id', 'libelle');
        return $record;
    }
}
