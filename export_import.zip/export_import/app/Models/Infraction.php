<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Infraction extends Model
{
    use HasFactory;
    protected $table = 'infractions';

    protected $fillable = ['admin_id', 'super_id', 'libelle_inf', 'type_id'];

    public static function getInfraction(){
        $record = DB::table('infractions')->select('admin_id', 'super_id', 'libelle_inf', 'type_id');
        return $record;
    }
}
