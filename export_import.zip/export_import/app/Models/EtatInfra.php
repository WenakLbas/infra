<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EtatInfra extends Model
{
    use HasFactory;
    protected $table = 'etat_infra_jours';

    protected $fillable = [
        'admin_id			',
        'super_id			',
        'date_infra',
        'etat_denonciation',
        'etat_enquette',
        'etat_garde_avue',
        'etat_decision_final',
        'etat_non_enqte',
        'etat_satisfaction',
        'etat_source_judiciaire',
        'etat_source_osc',
        'etat_media_source',
        'id_infra',
        'id_victime',
        'id_age',
        'id_province',
        'id_lieu_infra',
        'id_tinfra',


        'id_autho      ' ,
        'id_decision   ' ,
        'id_enqt       ' ,
        'id_gravue     ' ,
        'id_neqte      ' ,
        'id_satisfact  ' ,
        'id_judiciaire ' ,
        'id_osc        ' ,
        'id_media      ' ,
    ];
}
