<?php


namespace App\Exports;


class DetailReportDownload implements FromQuery, WithHeadings
{
    use Exportable;

    protected $plant,$from,$to;

    public function __construct(String  $from,String $to,String $plant)
    {
        $this->plant = $plant;
        $this->from = $from;
        $this->to = $to;
    }

    public function headings(): array
    {
        return [
            'plandate',
            'workcentre',
            'partno',
            'prodduration',
            'totaldowntime',
            'planout',
            'cumout',
        ];
    }

    public function query()
    {
        return  DB::table('plannings')
            ->select(DB::raw('plandate, workcentre, partno, prodduration, coalesce(sum(downduration),0) as totaldowntime, planout, cumout'))
            ->join('prodstatuses', 'plannings.id', '=', 'prodstatuses.id')
            ->leftJoin('downtimes', 'plannings.id', '=', 'downtimes.plan_id')
            ->whereBetween('plandate', array($this->from, $this->to))
            ->where('plant_id',$this->plant)
            ->where('status','Finished')
            ->groupBy('plannings.id')
            ->orderBy('plannings.id');
    }
}
/*
use App\Product;

use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class ProductsExport implements FromQuery
{
    use Exportable;

    public function query()
    {
        return Product::whereActive(1)->select(['pid', 'name', 'cost', 'min_price', 'max_price']);
    }
}


 use Illuminate\Support\Facades\DB;

public function query()
{
    return DB::table('products')
        ->join('product_shop', 'products.id', '=', 'product_shop.product_id')
        ->select('products.*', 'product_shop.price')
        ->where('products.active','=','1')
        ->orderBy('products.id');
}



namespace App\Exports;

use App\Product;

use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class ProductsExport implements FromQuery
{
    use Exportable;

    public function query()
    {
        return Product::whereActive(1)->select(['pid', 'name', 'cost', 'min_price', 'max_price']);
    }
}

----------------------------------------------------------laravel excel docs--------------------
==========>

namespace App\Exports;

use App\Invoice;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class InvoicesExport implements FromQuery
{
    use Exportable;

    public function query()
    {
        return Invoice::query();
    }
}

return (new InvoicesExport)->download('invoices.xlsx');


==========>

namespace App\Exports;

use App\Invoice;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class InvoicesExport implements FromQuery
{
    use Exportable;

    public function __construct(int $year)
    {
        $this->year = $year;
    }

    public function query()
    {
        return Invoice::query()->whereYear('created_at', $this->year);
    }
}

return (new InvoicesExport(2018))->download('invoices.xlsx');


namespace App\Exports;

use App\Invoice;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class InvoicesExport implements FromQuery
{
    use Exportable;

    public function forYear(int $year)
    {
        $this->year = $year;

        return $this;
    }

    public function query()
    {
        return Invoice::query()->whereYear('created_at', $this->year);
    }
}

==========>

namespace App\Exports;

use App\Invoice;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;

class InvoicesExport implements FromQuery
{
    use Exportable;

    public function forYear(int $year)
    {
        $this->year = $year;

        return $this;
    }

    public function query()
    {
        return Invoice::query()->whereYear('created_at', $this->year);
    }
}

return (new InvoicesExport)->forYear(2018)->download('invoices.xlsx');

----------------------------------------------------------laravel excel query--------------------
==========>

Book::join('authors', 'books.fk_author', 'authors.id')
    ->join('bookcases', 'books.fk_bookcase', 'bookcases.id')
    ->where('authors.name', 'LIKE', '%'. $req->search . '%')
    ->select('authors.name', 'table.other_column', 'table.another_column')
    ->paginate(5);

----------------------------------------------------------laravel excel count--------------------
==========>
$wordlist = Wordlist::where('id', '<=', $correctedComparisons)->get();
$wordCount = $wordlist->count();

// Query builder
$wordCount = \DB::table('wordlist')->where('id', '<=', $correctedComparisons)
            ->count();

// Eloquent
$wordCount = Wordlist::where('id', '<=', $correctedComparisons)->count();

*/

