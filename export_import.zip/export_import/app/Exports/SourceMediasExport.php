<?php

namespace App\Exports;

use App\Models\SourceMedias;
use Maatwebsite\Excel\Concerns\FromCollection;

class SourceMediasExport implements FromCollection
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return SourceMedias::all();
    }
}
