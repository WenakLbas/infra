<?php

namespace App\Exports;

use DB;
use App\Models\Infraction;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\FromQuery;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;

class InfractionExport implements FromCollection, ShouldAutoSize
{
    use Exportable;

    public function headings(): array
    {
        return [
            'Date',
            'Infraction',
            'Type infraction',
        ];
    }

    public function collection()
    {
        return Infraction::join('type_infractions', 'type_infractions.id', 'infractions.type_id')
            ->select('infractions.created_at', 'infractions.libelle_inf','type_infractions.libelle as t_infra_lib')
            ->get();
    }
}
