<?php

namespace App\Exports;

use App\Models\SourceJudiciaire;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;

class SourceJudiciaireExport implements FromCollection, ShouldAutoSize
{
    /**
    * @return \Illuminate\Support\Collection
    */
    public function collection()
    {
        return SourceJudiciaire::all();
    }
}
