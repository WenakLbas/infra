<?php

namespace App\Exports;

use App\Models\EtatInfra;
use App\Models\Infractions;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithHeadings;

class EtatInfraExport implements FromCollection, ShouldAutoSize, WithHeadingRow, WithHeadings
{
    protected $datefrom;
    protected $dateto;

    public function __construct($datefrom, $dateto)
    {
        $this->datefrom = $datefrom;
        $this->dateto = $dateto;
        // dd($datefrom, $dateto);
    }

    public function collection()
    {
        // dd($this->datefrom, $this->dateto);
        /*
        return EtatInfra::orderBy('date_infra', 'desc')
            ->join('provinces', 'etat_infra_jours.id_province',  '=', 'provinces.id')
            ->join('infractions', 'etat_infra_jours.id_infra',  '=', 'infractions.id')
            ->join('type_infractions', 'etat_infra_jours.id_tinfra',  '=', 'type_infractions.id')
            ->join('type_enquetes', 'etat_infra_jours.id_enqt',  '=', 'type_enquetes.id')
            ->join('rsnonenqtes', 'etat_infra_jours.id_neqte',  '=', 'rsnonenqtes.id')
            ->join('lieu_infras', 'etat_infra_jours.id_lieu_infra',  '=', 'lieu_infras.id')
            ->join('tranche_ages', 'etat_infra_jours.id_age',  '=', 'tranche_ages.id')
            ->join('autoritesaisies', 'etat_infra_jours.id_autho',  '=', 'autoritesaisies.id')
            ->join('gerdeavues', 'etat_infra_jours.id_gravue',  '=', 'gerdeavues.id')
            ->join('oscs', 'etat_infra_jours.id_osc',  '=', 'oscs.id')
            ->join('source_medias', 'etat_infra_jours.id_media',  '=', 'source_medias.id')
            ->join('source_judiciaires', 'etat_infra_jours.id_judiciaire',  '=', 'source_judiciaires.id')
            ->join('decision_finals', 'etat_infra_jours.id_decision',  '=', 'decision_finals.id')
            ->join('raison_satisfactions', 'etat_infra_jours.id_satisfact',  '=', 'raison_satisfactions.id')
            ->select('etat_infra_jours.date_infra', 'provinces.description',
                'tranche_ages.libelle as trange_age','infractions.libelle_inf','type_infractions.libelle as type_infraction',
                'lieu_infras.libelle as lieu_infraction', 'type_enquetes.libelle as type_enquete', 'rsnonenqtes.libelle as non_enquete'
                , 'gerdeavues.libelle as garde_avue', 'oscs.description as Organisation de droit'
                , 'source_medias.libelle as source_media', 'source_judiciaires.fonction'
                , 'decision_finals.libelle as decision', 'raison_satisfactions.libelle as satisfaction')
            ->whereBetween('etat_infra_jours.date_infra', [$this->datefrom, $this->dateto])
            ->get();
        */
        return Infractions::orderBy('date', 'desc')
            ->select('infras_imports.*',)
            ->whereBetween('infras_imports.date', [$this->datefrom, $this->dateto])
            ->get();
    }

    public function headings():array {
        return [
            'ID                    ',
            'Date                    ',
            'Localité                ',
            'Provinces               ',
            'Type d\'Infraction       ',
            'Infraction              ',
            'Consquence   ',
            'Source de l\'information ',
            'Nom media               ',
            'Nom de l\'OSC',
            'Nationalite',
            'Genre',
            'Categorie Professionnelle',
            'Tranche d\'age',
            'Denonciation verbale',
            'Autorité saisie',
            'Plainte',
            'Non pourquoi',
            'Enquete',
            'Type Enquete',
            'Qui a diligenté l’enquête',
            'Garde a  vue',
            'Durée  garde a vue',
            'Jugement',
            'Système Judiciaire',
            'Etat décision',
            'Pourquoi satisfait',
            'Pourquoi non satisfait'

        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class    => function(AfterSheet $event) {
                $cellRange = 'A1:P1'; // All headers
                $event->sheet->getDelegate()->getStyle($cellRange)->getFont()->setSize(14);
            },
            $styleArray = [
                'A1:P1',
                'borders' => [
                    'outline' => [
                        'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THICK,
                        'color' => ['argb' => 'FFFF0000'],
                    ],
                ],
            ],

        ];
    }
}
