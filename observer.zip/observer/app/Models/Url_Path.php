<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Url_Path extends Model
{
     const URL = 'http://localhost/lab/observer/public/images/';
    // const URL = 'https://observatoire-td.org/observer/public/images/';
}
